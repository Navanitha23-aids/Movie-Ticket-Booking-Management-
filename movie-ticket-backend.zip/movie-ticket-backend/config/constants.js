module.exports = {
  ROLES: {
    CUSTOMER: 'customer',
    STAFF: 'staff',
    MANAGER: 'manager',
    ADMIN: 'admin',
  },
  ROLES_LIST: ['customer', 'staff', 'manager', 'admin'],

  SHOW_TYPES: ['Regular', '3D', 'IMAX', 'VIP'],

  SEAT_TYPES: ['Regular', 'Premium', 'VIP', 'Recliner'],

  SEAT_STATUS: ['available', 'booked', 'held'],

  BOOKING_STATUS: {
    PENDING: 'pending',
    CONFIRMED: 'confirmed',
    CANCELLED: 'cancelled',
    EXPIRED: 'expired',
    ESCALATED: 'escalated',
  },

  PAYMENT_STATUS: {
    PENDING: 'pending',
    SUCCESS: 'success',
    FAILED: 'failed',
    REFUNDED: 'refunded',
  },

  MOVIE_STATUS: ['now_showing', 'upcoming', 'archived'],

  NOTIFICATION_TYPES: [
    'booking_confirmation',
    'booking_cancellation',
    'show_reminder',
    'sla_escalation',
    'payment_confirmation',
  ],

  NOTIFICATION_CHANNELS: ['email', 'sms', 'in_app'],

  // Routing queues by show type - useful metadata for Pega process routing
  SHOW_TYPE_ROUTE_QUEUE: {
    Regular: 'QUEUE_REGULAR_BOOKING',
    '3D': 'QUEUE_3D_BOOKING',
    IMAX: 'QUEUE_IMAX_PRIORITY_BOOKING',
    VIP: 'QUEUE_VIP_PRIORITY_BOOKING',
  },
};

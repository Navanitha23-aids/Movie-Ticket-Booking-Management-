# Movie Ticket Booking Management System — Backend

A complete backend for a Movie Ticket Booking Management Application, built for a Pega internship
project. Built with **Node.js, Express.js, MongoDB (Mongoose), JWT and bcrypt**.

Covers all 10 required features plus 7 innovative features, with clean layering
(`models / controllers / routes / services / middleware / config / utils`), role-based
access control, atomic double-booking prevention, mock payments, QR e-tickets, dynamic
pricing, SLA/escalation handling, and admin analytics — all exposed as REST APIs so they
plug directly into Pega (or any REST-capable orchestrator/frontend) as connectors.

---

## 1. Tech Stack

| Layer | Technology |
|---|---|
| Runtime | Node.js (>=18) |
| Framework | Express.js |
| Database | MongoDB + Mongoose |
| Auth | JWT + bcryptjs |
| Validation | express-validator |
| QR Codes | `qrcode` npm package |
| Scheduling | `node-cron` (SLA sweeps, show reminders) |
| Security | helmet, cors, express-rate-limit |

---

## 2. Project Structure

```
movie-ticket-backend/
├── server.js                 # App entry point, middleware wiring, cron jobs
├── package.json
├── .env.example               # Copy to .env and fill in your own values
├── config/
│   ├── db.js                  # MongoDB connection
│   └── constants.js           # Roles, enums, SLA route-queue mapping
├── models/                    # Mongoose schemas
│   ├── User.js
│   ├── Movie.js
│   ├── Theatre.js
│   ├── Screen.js
│   ├── Seat.js
│   ├── Show.js
│   ├── Booking.js
│   ├── Payment.js
│   └── Notification.js
├── controllers/                # Request/response handling only
├── routes/                     # Express routers, validation chains, RBAC wiring
├── services/                   # ALL business logic lives here
│   ├── bookingService.js       # Booking lifecycle + atomic double-booking prevention
│   ├── pricingService.js       # Dynamic pricing engine
│   ├── seatRecommendationService.js
│   ├── recommendationService.js # AI-lite content-based movie recommendations
│   ├── ticketService.js        # QR e-ticket generation + signature verification
│   ├── paymentService.js       # Mock payment gateway
│   ├── slaService.js           # SLA breach detection + escalation
│   ├── reminderService.js      # Automatic show reminders
│   ├── analyticsService.js     # Aggregation queries for the admin dashboard
│   └── routingService.js       # Routes bookings to a queue by show type
├── middleware/
│   ├── authMiddleware.js       # JWT verification
│   ├── roleMiddleware.js       # Role-based access control
│   ├── validateMiddleware.js   # express-validator error handling
│   ├── errorMiddleware.js      # Centralized error handler
│   └── asyncHandler.js
├── utils/
│   ├── apiResponse.js          # Consistent { success, message, data } contract
│   ├── generateToken.js
│   ├── generateCode.js         # Booking codes / transaction IDs
│   └── logger.js
└── seed/
    └── seedData.js             # Demo data generator (npm run seed)
```

---

## 3. Setup Instructions

### Prerequisites
- Node.js 18+
- MongoDB running locally (`mongodb://127.0.0.1:27017`) or a MongoDB Atlas connection string
- **Note:** this project was built and syntax/wiring-checked in a sandboxed environment
  with no MongoDB server or internet access to install one, so it has **not** been run
  against a live database yet. Every route module was verified to load without errors,
  and the DB connection logic was confirmed to behave correctly (clean connection error
  when no DB is reachable). Please run the steps below on your machine to do a full
  end-to-end smoke test before relying on it.

### Steps

```bash
# 1. Extract the ZIP and move into the project folder
cd movie-ticket-backend

# 2. Install dependencies
npm install

# 3. Configure environment variables
cp .env.example .env
# Edit .env - at minimum set MONGO_URI and a strong JWT_SECRET

# 4. Seed demo data (creates admin/manager/staff/customer users, movies, theatres,
#    screens with auto-generated seat layouts, and shows)
npm run seed

# 5. Start the server
npm run dev      # with nodemon (auto-restart)
# or
npm start        # plain node
```

The API will be available at `http://localhost:5000` (or your configured `PORT`).
Health check: `GET /api/health`.

### Demo credentials (created by `npm run seed`)

| Role | Email | Password |
|---|---|---|
| Admin | admin@movieapp.com | Admin@123 |
| Manager | manager@movieapp.com | Manager@123 |
| Staff | staff@movieapp.com | Staff@123 |
| Customer | customer1@movieapp.com | Customer@123 |
| Customer | customer2@movieapp.com | Customer@123 |

> These are demo-only credentials seeded into your **own local database** — they are not
> shipped anywhere else and this ZIP contains no real secrets, API keys, or `.env` file.

---

## 4. Role-Based Access Control

Roles: `customer`, `staff`, `manager`, `admin`.

- **customer** — browse movies/shows, get quotes, book, pay, cancel own bookings, view own
  tickets/notifications/recommendations.
- **staff** — everything a customer can view for management purposes, plus verify tickets
  (QR scan at the entrance), view all bookings.
- **manager** — everything staff can do, plus manage movies, theatres, screens, shows.
- **admin** — full access, including creating staff/manager accounts and analytics.

Staff/manager/admin accounts are **not** self-registerable — they're created by an admin via
`POST /api/auth/create-staff` to prevent privilege escalation through public signup.

---

## 5. How Each Required Feature Is Implemented

| # | Feature | Where |
|---|---|---|
| 1 | Submit movie ticket request | `POST /api/bookings` |
| 2 | Check movie/show/seat availability | `GET /api/shows/:id/availability` |
| 3 | Calculate booking cost | `POST /api/bookings/quote` |
| 4 | Customer booking confirmation | `POST /api/payments/pay` (confirms booking + generates ticket) |
| 5 | Movie, theatre, screen, show management | `/api/movies`, `/api/theatres`, `/api/screens`, `/api/shows` (manager/admin) |
| 6 | View booking details | `GET /api/bookings/:id`, `GET /api/bookings/my` |
| 7 | Process booking | `bookingService.createBooking` (submit) → `paymentController.payForBooking` (complete) |
| 8 | Booking confirmation notifications | `notificationService`, triggered from `paymentController` |
| 9 | Booking SLA and escalation | `slaService` + cron in `server.js` (runs every minute) |
| 10 | Route booking based on show type | `routingService.routeBookingByShowType` — every booking response includes `routeQueue` + `priority` for Pega to branch on |

## 6. Innovative Features

| Feature | Where |
|---|---|
| AI-based movie recommendation | `GET /api/recommendations` — content-based genre profile built from booking history + stated preferences, with a popularity fallback for new/cold-start users |
| Smart seat recommendation | `GET /api/shows/:id/seat-recommendation?numSeats=N` — prefers contiguous seats in center rows |
| Dynamic pricing | `pricingService` — factors in seat type, weekend, peak hours (6–11 PM), and live demand (occupancy %) |
| QR-code e-ticket generation & verification | `GET /api/tickets/:bookingId`, `POST /api/tickets/verify` — HMAC-signed payload so tickets can't be forged |
| Booking cancellation + automatic seat release | `POST /api/bookings/:id/cancel` |
| Admin analytics dashboard | `GET /api/analytics/dashboard`, `/revenue`, `/sla` |
| Automatic show reminders | `reminderService` + cron (runs every 10 minutes) |

---

## 7. Double-Booking Prevention (Important Design Note)

Seat reservation uses a **single atomic MongoDB update** rather than multi-document
transactions (which require a replica set):

```js
Show.findOneAndUpdate(
  { _id: showId, status: 'scheduled', bookedSeats: { $nin: seatNumbers } },
  { $push: { bookedSeats: { $each: seatNumbers } } },
  { new: true }
);
```

If two requests race for the same seat, MongoDB's per-document atomicity guarantees only
one `findOneAndUpdate` matches (the seat is no longer `$nin` for the loser), and the losing
request receives `null` back, which the service converts into a `409 Conflict` with the
list of conflicting seats. This works reliably on a standalone MongoDB instance — no
replica set required.

---

## 8. SLA & Escalation Flow

1. On `POST /api/bookings`, seats are reserved immediately and the booking is created with
   `status: 'pending'`, `slaDeadline` (default 10 min) and `escalationDeadline` (default 15 min).
2. A cron job runs every minute:
   - Bookings still `pending` past `escalationDeadline` (but before `slaDeadline`) are
     flagged `isEscalated: true` and staff/admin/manager + the customer are notified.
   - Bookings still `pending` past `slaDeadline` are auto-`expired` and their seats released.
3. Paying via `POST /api/payments/pay` before the deadline confirms the booking and cancels
   the SLA clock.

Configure the windows via `.env`: `BOOKING_PAYMENT_SLA_MINUTES`, `BOOKING_ESCALATION_SLA_MINUTES`.

---

## 9. Integrating with Pega

- All responses follow a consistent JSON contract: `{ success, message, data, meta? }` —
  easy to map in a Pega Data Transform / REST Connector.
- Every booking response includes `routeQueue` and `priority` so a Pega flow can branch
  case routing based on show type (Regular/3D/IMAX/VIP) without extra logic on the Pega side.
- Use `POST /api/auth/login` to obtain a JWT, then send `Authorization: Bearer <token>` on
  subsequent REST Connector calls.
- `GET /api/health` is provided for connector health-check configuration.
- CORS is open (`CORS_ORIGIN=*` by default) for easy integration; lock this down in `.env`
  for production.

---

## 10. Full API Reference

Base URL: `http://localhost:5000/api`

All protected routes require header: `Authorization: Bearer <JWT>`

### Auth (`/auth`)
| Method | Endpoint | Access | Description |
|---|---|---|---|
| POST | `/auth/register` | Public | Register a new customer |
| POST | `/auth/login` | Public | Login, returns JWT |
| POST | `/auth/create-staff` | Admin | Create staff/manager/admin account |
| GET | `/auth/me` | Authenticated | Get current profile |
| PUT | `/auth/me` | Authenticated | Update name/phone/preferences |

### Movies (`/movies`)
| Method | Endpoint | Access | Description |
|---|---|---|---|
| GET | `/movies` | Public | List movies (`?status=&genre=&search=&page=&limit=`) |
| GET | `/movies/:id` | Public | Movie details |
| POST | `/movies` | Manager/Admin | Create movie |
| PUT | `/movies/:id` | Manager/Admin | Update movie |
| DELETE | `/movies/:id` | Admin | Archive movie |

### Theatres (`/theatres`)
| Method | Endpoint | Access | Description |
|---|---|---|---|
| GET | `/theatres` | Public | List theatres (`?city=`) |
| GET | `/theatres/:id` | Public | Theatre details |
| POST | `/theatres` | Manager/Admin | Create theatre |
| PUT | `/theatres/:id` | Manager/Admin | Update theatre |
| DELETE | `/theatres/:id` | Admin | Deactivate theatre |

### Screens (`/screens`)
| Method | Endpoint | Access | Description |
|---|---|---|---|
| GET | `/screens?theatre=` | Public | List screens |
| GET | `/screens/:id` | Public | Screen details + seat map |
| POST | `/screens` | Manager/Admin | Create screen (auto-generates seat layout) |
| PUT | `/screens/:id` | Manager/Admin | Update screen |
| DELETE | `/screens/:id` | Admin | Deactivate screen |

### Seats (`/seats`)
| Method | Endpoint | Access | Description |
|---|---|---|---|
| GET | `/seats?screen=` | Public | Get physical seat layout for a screen |
| PUT | `/seats/:id` | Manager/Admin | Update a seat (type, active status) |

### Shows (`/shows`)
| Method | Endpoint | Access | Description |
|---|---|---|---|
| GET | `/shows` | Public | List shows (`?movie=&theatre=&date=&showType=`) |
| GET | `/shows/:id` | Public | Show details |
| GET | `/shows/:id/availability` | Public | **Feature 2** — seat-by-seat availability + live price |
| GET | `/shows/:id/seat-recommendation?numSeats=N` | Public | Smart seat recommendation |
| POST | `/shows` | Manager/Admin | Schedule a show |
| PUT | `/shows/:id` | Manager/Admin | Update a show |
| POST | `/shows/:id/cancel` | Manager/Admin | Cancel a show |

### Bookings (`/bookings`) — all require authentication
| Method | Endpoint | Access | Description |
|---|---|---|---|
| POST | `/bookings/quote` | Customer+ | **Feature 3** — calculate cost without reserving seats |
| POST | `/bookings` | Customer+ | **Feature 1/7** — submit booking request (reserves seats, status `pending`) |
| GET | `/bookings/my` | Customer+ | **Feature 6** — own booking history |
| GET | `/bookings` | Staff/Manager/Admin | View all bookings (`?status=&theatre=&showType=`) |
| GET | `/bookings/:id` | Owner or Staff+ | **Feature 6** — booking details |
| POST | `/bookings/:id/cancel` | Owner or Staff+ | Cancel + auto-release seats |

### Payments (`/payments`) — require authentication
| Method | Endpoint | Access | Description |
|---|---|---|---|
| POST | `/payments/pay` | Customer+ | Mock-pay a pending booking → confirms it, generates QR ticket, sends notifications (**Features 4, 7, 8**) |
| GET | `/payments/:id` | Owner or Staff+ | Payment details |

### Tickets (`/tickets`) — require authentication
| Method | Endpoint | Access | Description |
|---|---|---|---|
| GET | `/tickets/:bookingId` | Owner or Staff+ | Get QR e-ticket for a confirmed booking |
| POST | `/tickets/verify` | Staff/Manager/Admin | Verify a scanned QR ticket at entrance |

### Notifications (`/notifications`) — require authentication
| Method | Endpoint | Access | Description |
|---|---|---|---|
| GET | `/notifications` | Authenticated | List own notifications (`?isRead=`) |
| PUT | `/notifications/:id/read` | Authenticated | Mark one as read |
| PUT | `/notifications/read-all` | Authenticated | Mark all as read |

### Recommendations (`/recommendations`)
| Method | Endpoint | Access | Description |
|---|---|---|---|
| GET | `/recommendations/trending` | Public | Trending/most-booked movies |
| GET | `/recommendations` | Authenticated | Personalized AI-based recommendations |

### Analytics (`/analytics`) — Manager/Admin only
| Method | Endpoint | Description |
|---|---|---|
| GET | `/analytics/dashboard` | Full dashboard: revenue, by show type, top movies, occupancy, status breakdown, SLA metrics, 14-day trend |
| GET | `/analytics/revenue?from=&to=` | Revenue summary |
| GET | `/analytics/sla` | SLA/escalation metrics |

---

## 11. Example: End-to-End Booking Flow

```bash
# 1. Login
POST /api/auth/login  { "email": "customer1@movieapp.com", "password": "Customer@123" }
# -> { data: { token } }

# 2. Check availability
GET /api/shows/<showId>/availability

# 3. (Optional) Get smart seat suggestion
GET /api/shows/<showId>/seat-recommendation?numSeats=2

# 4. Get a cost quote
POST /api/bookings/quote  { "showId": "...", "seatNumbers": ["A4","A5"] }

# 5. Submit the booking request (reserves seats, status=pending)
POST /api/bookings  { "showId": "...", "seatNumbers": ["A4","A5"] }
# -> { data: { booking: { _id, bookingCode, slaDeadline, ... } } }

# 6. Pay (before slaDeadline!) -> confirms booking + generates QR ticket
POST /api/payments/pay  { "bookingId": "...", "method": "upi" }

# 7. Fetch the e-ticket
GET /api/tickets/<bookingId>

# 8. At the venue: staff verifies the QR
POST /api/tickets/verify  { "bookingCode": "BKG-XXXX", "scannedData": "<raw QR JSON>" }
```

---

## 12. Response Contract

All endpoints return:
```json
{
  "success": true,
  "message": "Human readable message",
  "data": { },
  "meta": { "total": 0, "page": 1, "limit": 20 }
}
```
Errors:
```json
{
  "success": false,
  "message": "What went wrong",
  "errors": [ { "field": "email", "message": "Valid email is required" } ]
}
```

---

## 13. What Was and Wasn't Tested

- ✅ All 60+ source files pass `node --check` (no syntax errors).
- ✅ All route modules load without missing-import/wiring errors.
- ✅ `config/db.js` connection logic verified to fail cleanly and quickly when no DB is reachable.
- ⚠️ **Not yet run against a live MongoDB** — the sandbox this was built in had no MongoDB
  server and no network access to install one (`mongodb.org` download hosts are blocked in
  that environment). Please run `npm install && npm run seed && npm run dev` and exercise
  the flow in Section 11 as your first step after downloading this ZIP, and file/fix any
  issues you hit — the logic has been carefully reviewed but a full integration test on
  your machine is still recommended before treating this as production-ready.

---

## 14. Security Notes

- Passwords are hashed with bcrypt (10 salt rounds), never returned in API responses.
- JWT secret, DB URI, and all config live in `.env` (gitignored, not included in this ZIP).
- `helmet`, `cors`, and `express-rate-limit` are applied globally.
- Role checks are enforced server-side on every protected route, not just at the UI layer.
- QR tickets are HMAC-signed so they can't be forged or replayed after verification.

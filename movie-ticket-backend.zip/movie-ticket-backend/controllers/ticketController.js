const Booking = require('../models/Booking');
const { success, failure } = require('../utils/apiResponse');
const asyncHandler = require('../middleware/asyncHandler');
const ticketService = require('../services/ticketService');

// @route GET /api/tickets/:bookingId  - returns the QR e-ticket for a confirmed booking
const getTicket = asyncHandler(async (req, res) => {
  const booking = await Booking.findById(req.params.bookingId)
    .populate('movie', 'title poster duration')
    .populate('theatre', 'name location')
    .populate('screen', 'name screenType')
    .populate('show', 'startTime endTime');

  if (!booking) return failure(res, 404, 'Booking not found');
  if (req.user.role === 'customer' && booking.user.toString() !== req.user._id.toString()) {
    return failure(res, 403, 'Not authorized to view this ticket');
  }
  if (booking.status !== 'confirmed') {
    return failure(res, 400, `Ticket not available - booking status is '${booking.status}'`);
  }

  return success(res, 200, 'E-ticket fetched', {
    bookingCode: booking.bookingCode,
    movie: booking.movie,
    theatre: booking.theatre,
    screen: booking.screen,
    show: booking.show,
    seats: booking.seats,
    totalAmount: booking.totalAmount,
    qrCode: booking.qrCode,
    verified: booking.ticketVerified,
  });
});

// @route POST /api/tickets/verify  (staff/manager scan QR at entrance)
// body: { bookingCode, scannedData }  - scannedData is the raw JSON string decoded from the QR
const verifyTicket = asyncHandler(async (req, res) => {
  const { bookingCode, scannedData } = req.body;
  if (!bookingCode || !scannedData) {
    return failure(res, 400, 'bookingCode and scannedData are required');
  }

  const booking = await Booking.findOne({ bookingCode });
  const result = ticketService.verifyTicket(scannedData, booking);

  if (!result.valid) {
    return failure(res, 400, result.reason, { alreadyVerified: !!result.alreadyVerified });
  }

  booking.ticketVerified = true;
  booking.ticketVerifiedAt = new Date();
  await booking.save();

  return success(res, 200, 'Ticket verified - entry approved', {
    bookingCode: booking.bookingCode,
    seats: booking.seats,
    verifiedAt: booking.ticketVerifiedAt,
  });
});

module.exports = { getTicket, verifyTicket };

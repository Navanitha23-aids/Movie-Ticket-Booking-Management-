const Theatre = require('../models/Theatre');
const { success, failure } = require('../utils/apiResponse');
const asyncHandler = require('../middleware/asyncHandler');

const createTheatre = asyncHandler(async (req, res) => {
  const theatre = await Theatre.create(req.body);
  return success(res, 201, 'Theatre created successfully', { theatre });
});

const getTheatres = asyncHandler(async (req, res) => {
  const { city, page = 1, limit = 20 } = req.query;
  const filter = { isActive: true };
  if (city) filter['location.city'] = new RegExp(city, 'i');

  const skip = (Number(page) - 1) * Number(limit);
  const [theatres, total] = await Promise.all([
    Theatre.find(filter).skip(skip).limit(Number(limit)),
    Theatre.countDocuments(filter),
  ]);

  return success(res, 200, 'Theatres fetched', { theatres }, { total, page: Number(page), limit: Number(limit) });
});

const getTheatreById = asyncHandler(async (req, res) => {
  const theatre = await Theatre.findById(req.params.id);
  if (!theatre) return failure(res, 404, 'Theatre not found');
  return success(res, 200, 'Theatre fetched', { theatre });
});

const updateTheatre = asyncHandler(async (req, res) => {
  const theatre = await Theatre.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  if (!theatre) return failure(res, 404, 'Theatre not found');
  return success(res, 200, 'Theatre updated', { theatre });
});

const deleteTheatre = asyncHandler(async (req, res) => {
  const theatre = await Theatre.findByIdAndUpdate(req.params.id, { isActive: false }, { new: true });
  if (!theatre) return failure(res, 404, 'Theatre not found');
  return success(res, 200, 'Theatre deactivated', { theatre });
});

module.exports = { createTheatre, getTheatres, getTheatreById, updateTheatre, deleteTheatre };

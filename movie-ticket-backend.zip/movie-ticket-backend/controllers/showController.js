const Show = require('../models/Show');
const Screen = require('../models/Screen');
const Seat = require('../models/Seat');
const { success, failure } = require('../utils/apiResponse');
const asyncHandler = require('../middleware/asyncHandler');
const seatRecommendationService = require('../services/seatRecommendationService');
const pricingService = require('../services/pricingService');

// @route POST /api/shows (manager/admin)
const createShow = asyncHandler(async (req, res) => {
  const { movie, theatre, screen, showType, date, startTime, endTime, basePrice } = req.body;

  const screenDoc = await Screen.findById(screen);
  if (!screenDoc) return failure(res, 404, 'Screen not found');

  // Prevent overlapping shows on the same screen
  const overlap = await Show.findOne({
    screen,
    status: { $ne: 'cancelled' },
    $or: [{ startTime: { $lt: new Date(endTime) }, endTime: { $gt: new Date(startTime) } }],
  });
  if (overlap) {
    return failure(res, 409, 'This screen already has an overlapping show scheduled in that time slot');
  }

  const show = await Show.create({
    movie,
    theatre,
    screen,
    showType,
    date,
    startTime,
    endTime,
    basePrice,
    totalSeats: screenDoc.totalSeats,
    bookedSeats: [],
  });

  return success(res, 201, 'Show scheduled successfully', { show });
});

// @route GET /api/shows?movie=&theatre=&date=&showType=&city=
const getShows = asyncHandler(async (req, res) => {
  const { movie, theatre, date, showType, status } = req.query;
  const filter = {};
  if (movie) filter.movie = movie;
  if (theatre) filter.theatre = theatre;
  if (showType) filter.showType = showType;
  filter.status = status || 'scheduled';

  if (date) {
    const start = new Date(date);
    start.setHours(0, 0, 0, 0);
    const end = new Date(date);
    end.setHours(23, 59, 59, 999);
    filter.startTime = { $gte: start, $lte: end };
  }

  const shows = await Show.find(filter)
    .populate('movie', 'title poster duration genre')
    .populate('theatre', 'name location')
    .populate('screen', 'name screenType')
    .sort({ startTime: 1 });

  return success(res, 200, 'Shows fetched', { shows });
});

const getShowById = asyncHandler(async (req, res) => {
  const show = await Show.findById(req.params.id)
    .populate('movie')
    .populate('theatre', 'name location')
    .populate('screen');
  if (!show) return failure(res, 404, 'Show not found');
  return success(res, 200, 'Show fetched', { show });
});

// @route GET /api/shows/:id/availability  (feature 2: check movie/show/seat availability)
const checkAvailability = asyncHandler(async (req, res) => {
  const show = await Show.findById(req.params.id).populate('movie', 'title').populate('screen');
  if (!show) return failure(res, 404, 'Show not found');

  const allSeats = await Seat.find({ screen: show.screen._id, isActive: true }).sort({ row: 1, column: 1 });

  const seatsWithStatus = allSeats.map((seat) => {
    const isBooked = show.bookedSeats.includes(seat.seatNumber);
    const priceCalc = pricingService.calculateSeatPrice({
      basePrice: show.basePrice,
      seatTypeMultiplier: seat.basePriceMultiplier,
      showDateTime: show.startTime,
      bookedCount: show.bookedSeats.length,
      totalSeats: show.totalSeats,
    });
    return {
      seatNumber: seat.seatNumber,
      row: seat.row,
      column: seat.column,
      seatType: seat.seatType,
      status: isBooked ? 'booked' : 'available',
      currentPrice: priceCalc.finalPrice,
    };
  });

  const availableCount = show.totalSeats - show.bookedSeats.length;

  return success(res, 200, 'Availability fetched', {
    show: {
      id: show._id,
      movie: show.movie.title,
      showType: show.showType,
      startTime: show.startTime,
      totalSeats: show.totalSeats,
      availableSeats: availableCount,
      occupancyPercent: Math.round((show.bookedSeats.length / show.totalSeats) * 10000) / 100,
    },
    seats: seatsWithStatus,
  });
});

// @route GET /api/shows/:id/seat-recommendation?numSeats=3  (Smart seat recommendation)
const getSeatRecommendation = asyncHandler(async (req, res) => {
  const numSeats = parseInt(req.query.numSeats || '1', 10);
  if (numSeats < 1) return failure(res, 400, 'numSeats must be at least 1');

  const show = await Show.findById(req.params.id);
  if (!show) return failure(res, 404, 'Show not found');

  const allSeats = await Seat.find({ screen: show.screen, isActive: true }).sort({ row: 1, column: 1 });
  const result = seatRecommendationService.recommendSeats(allSeats, show.bookedSeats, numSeats);

  return success(res, 200, 'Seat recommendation generated', result);
});

const updateShow = asyncHandler(async (req, res) => {
  const show = await Show.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  if (!show) return failure(res, 404, 'Show not found');
  return success(res, 200, 'Show updated', { show });
});

const cancelShow = asyncHandler(async (req, res) => {
  const show = await Show.findByIdAndUpdate(req.params.id, { status: 'cancelled' }, { new: true });
  if (!show) return failure(res, 404, 'Show not found');
  // NOTE: in a full implementation this would cascade-cancel bookings + trigger refunds
  return success(res, 200, 'Show cancelled', { show });
});

module.exports = {
  createShow,
  getShows,
  getShowById,
  checkAvailability,
  getSeatRecommendation,
  updateShow,
  cancelShow,
};

const Booking = require('../models/Booking');
const Show = require('../models/Show');
const Seat = require('../models/Seat');

const { success, failure } = require('../utils/apiResponse');
const asyncHandler = require('../middleware/asyncHandler');

const bookingService = require('../services/bookingService');
const pricingService = require('../services/pricingService');
const paymentService = require('../services/paymentService');
const ticketService = require('../services/ticketService');
const notificationService = require('../services/notificationService');

// @route POST /api/bookings/quote  (feature 3: calculate booking cost, no reservation made)
const getBookingQuote = asyncHandler(async (req, res) => {
  const { showId, seatNumbers } = req.body;
  if (!showId || !seatNumbers || !Array.isArray(seatNumbers) || seatNumbers.length === 0) {
    return failure(res, 400, 'showId and a non-empty seatNumbers array are required');
  }

  const show = await Show.findById(showId).populate('movie', 'title').populate('screen');
  if (!show) return failure(res, 404, 'Show not found');

  const uniqueSeats = [...new Set(seatNumbers)];
  const seatDocs = await Seat.find({ screen: show.screen._id, seatNumber: { $in: uniqueSeats }, isActive: true });
  if (seatDocs.length !== uniqueSeats.length) {
    return failure(res, 400, 'One or more seat numbers are invalid for this screen');
  }

  const alreadyBooked = uniqueSeats.filter((s) => show.bookedSeats.includes(s));
  if (alreadyBooked.length > 0) {
    return failure(res, 409, `Seat(s) already booked: ${alreadyBooked.join(', ')}`);
  }

  const costCalc = pricingService.calculateBookingCost({ show, seatsInfo: seatDocs });

  return success(res, 200, 'Booking cost calculated', {
    show: { id: show._id, movie: show.movie.title, showType: show.showType, startTime: show.startTime },
    seats: uniqueSeats,
    ...costCalc,
  });
});

// @route POST /api/bookings  (feature 1: submit movie ticket request / feature 7: process booking - initiates pending booking)
const submitBookingRequest = asyncHandler(async (req, res) => {
  const { showId, seatNumbers } = req.body;
  if (!showId || !seatNumbers || !Array.isArray(seatNumbers) || seatNumbers.length === 0) {
    return failure(res, 400, 'showId and a non-empty seatNumbers array are required');
  }

  const booking = await bookingService.createBooking({
    userId: req.user._id,
    showId,
    seatNumbers,
  });

  return success(res, 201, 'Booking request submitted. Complete payment to confirm before the SLA deadline.', {
    booking,
    slaDeadline: booking.slaDeadline,
    note: 'Seats are held for you. Call POST /api/payments/pay to confirm this booking before slaDeadline or the seats will be auto-released.',
  });
});

// @route GET /api/bookings/:id  (feature 6: view booking details)
const getBookingById = asyncHandler(async (req, res) => {
  const booking = await Booking.findById(req.params.id)
    .populate('movie', 'title poster duration')
    .populate('theatre', 'name location')
    .populate('screen', 'name screenType')
    .populate('show', 'startTime endTime showType')
    .populate('payment');

  if (!booking) return failure(res, 404, 'Booking not found');

  // Customers can only view their own bookings
  if (req.user.role === 'customer' && booking.user.toString() !== req.user._id.toString()) {
    return failure(res, 403, 'You are not authorized to view this booking');
  }

  return success(res, 200, 'Booking details fetched', { booking });
});

// @route GET /api/bookings/my  (feature 6: view own booking history)
const getMyBookings = asyncHandler(async (req, res) => {
  const { status, page = 1, limit = 20 } = req.query;
  const filter = { user: req.user._id };
  if (status) filter.status = status;

  const skip = (Number(page) - 1) * Number(limit);
  const [bookings, total] = await Promise.all([
    Booking.find(filter)
      .populate('movie', 'title poster')
      .populate('theatre', 'name')
      .populate('show', 'startTime showType')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number(limit)),
    Booking.countDocuments(filter),
  ]);

  return success(res, 200, 'Bookings fetched', { bookings }, { total, page: Number(page), limit: Number(limit) });
});

// @route GET /api/bookings (staff/manager/admin) - view all bookings, filterable
const getAllBookings = asyncHandler(async (req, res) => {
  const { status, theatre, showType, page = 1, limit = 20 } = req.query;
  const filter = {};
  if (status) filter.status = status;
  if (theatre) filter.theatre = theatre;
  if (showType) filter.showType = showType;

  const skip = (Number(page) - 1) * Number(limit);
  const [bookings, total] = await Promise.all([
    Booking.find(filter)
      .populate('user', 'name email')
      .populate('movie', 'title')
      .populate('theatre', 'name')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number(limit)),
    Booking.countDocuments(filter),
  ]);

  return success(res, 200, 'All bookings fetched', { bookings }, { total, page: Number(page), limit: Number(limit) });
});

// @route POST /api/bookings/:id/cancel  (Booking cancellation with automatic seat release)
const cancelBooking = asyncHandler(async (req, res) => {
  const booking = await Booking.findById(req.params.id);
  if (!booking) return failure(res, 404, 'Booking not found');

  if (req.user.role === 'customer' && booking.user.toString() !== req.user._id.toString()) {
    return failure(res, 403, 'You are not authorized to cancel this booking');
  }

  const cancelled = await bookingService.cancelBooking(booking, req.body.reason);

  // If a payment had succeeded, mock-refund it
  if (cancelled.payment) {
    await paymentService.refundMockPayment(cancelled.payment);
  }

  await notificationService.notifyBookingCancellation(cancelled, req.user, req.body.reason);

  return success(res, 200, 'Booking cancelled and seats released', { booking: cancelled });
});

module.exports = {
  getBookingQuote,
  submitBookingRequest,
  getBookingById,
  getMyBookings,
  getAllBookings,
  cancelBooking,
};

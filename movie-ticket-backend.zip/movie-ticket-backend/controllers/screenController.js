const Screen = require('../models/Screen');
const Seat = require('../models/Seat');
const { success, failure } = require('../utils/apiResponse');
const asyncHandler = require('../middleware/asyncHandler');

// Utility: auto-generate seat layout for a screen (rows A, B, C... x seatsPerRow)
// Middle rows are marked Premium, back rows VIP/Recliner-ish for a realistic layout demo.
const generateSeatLayout = async (screen) => {
  const rows = [];
  for (let i = 0; i < screen.totalRows; i++) {
    rows.push(String.fromCharCode(65 + i)); // A, B, C, ...
  }

  const seatDocs = [];
  rows.forEach((row, rowIndex) => {
    let seatType = 'Regular';
    let multiplier = 1;
    const fromBack = screen.totalRows - rowIndex;
    if (fromBack <= 2) {
      seatType = 'VIP';
      multiplier = 2;
    } else if (fromBack <= Math.ceil(screen.totalRows / 2)) {
      seatType = 'Premium';
      multiplier = 1.5;
    }

    for (let col = 1; col <= screen.seatsPerRow; col++) {
      seatDocs.push({
        screen: screen._id,
        seatNumber: `${row}${col}`,
        row,
        column: col,
        seatType,
        basePriceMultiplier: multiplier,
      });
    }
  });

  await Seat.insertMany(seatDocs, { ordered: false }).catch(() => {}); // ignore dup key on re-seed
  return seatDocs.length;
};

// @route POST /api/screens (admin/manager)
const createScreen = asyncHandler(async (req, res) => {
  const { theatre, name, screenType, totalRows, seatsPerRow } = req.body;
  const totalSeats = totalRows * seatsPerRow;

  const screen = await Screen.create({ theatre, name, screenType, totalRows, seatsPerRow, totalSeats });
  const seatsCreated = await generateSeatLayout(screen);

  return success(res, 201, 'Screen created and seat layout generated', { screen, seatsCreated });
});

const getScreens = asyncHandler(async (req, res) => {
  const { theatre } = req.query;
  const filter = { isActive: true };
  if (theatre) filter.theatre = theatre;
  const screens = await Screen.find(filter).populate('theatre', 'name location');
  return success(res, 200, 'Screens fetched', { screens });
});

const getScreenById = asyncHandler(async (req, res) => {
  const screen = await Screen.findById(req.params.id).populate('theatre', 'name location');
  if (!screen) return failure(res, 404, 'Screen not found');
  const seats = await Seat.find({ screen: screen._id, isActive: true }).sort({ row: 1, column: 1 });
  return success(res, 200, 'Screen fetched', { screen, seats });
});

const updateScreen = asyncHandler(async (req, res) => {
  const screen = await Screen.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  if (!screen) return failure(res, 404, 'Screen not found');
  return success(res, 200, 'Screen updated', { screen });
});

const deleteScreen = asyncHandler(async (req, res) => {
  const screen = await Screen.findByIdAndUpdate(req.params.id, { isActive: false }, { new: true });
  if (!screen) return failure(res, 404, 'Screen not found');
  return success(res, 200, 'Screen deactivated', { screen });
});

module.exports = { createScreen, getScreens, getScreenById, updateScreen, deleteScreen, generateSeatLayout };

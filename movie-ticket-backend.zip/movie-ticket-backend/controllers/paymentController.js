const Booking = require('../models/Booking');
const { success, failure } = require('../utils/apiResponse');
const asyncHandler = require('../middleware/asyncHandler');

const paymentService = require('../services/paymentService');
const ticketService = require('../services/ticketService');
const notificationService = require('../services/notificationService');

// @route POST /api/payments/pay  (mock payment -> confirms booking -> generates QR e-ticket -> sends notification)
// This single endpoint covers feature 4 (customer booking confirmation), feature 7
// (process booking to completion) and feature 8 (booking confirmation notification).
const payForBooking = asyncHandler(async (req, res) => {
  const { bookingId, method } = req.body;
  if (!bookingId) return failure(res, 400, 'bookingId is required');

  const booking = await Booking.findById(bookingId).populate('show');
  if (!booking) return failure(res, 404, 'Booking not found');

  if (booking.user.toString() !== req.user._id.toString()) {
    return failure(res, 403, 'You are not authorized to pay for this booking');
  }

  if (booking.status === 'expired') {
    return failure(res, 410, 'This booking has expired (SLA breach) - please create a new booking');
  }
  if (booking.status === 'cancelled') {
    return failure(res, 400, 'This booking has already been cancelled');
  }
  if (booking.status === 'confirmed') {
    return failure(res, 400, 'This booking is already confirmed');
  }
  if (new Date() > new Date(booking.slaDeadline)) {
    return failure(res, 410, 'Payment window (SLA) has passed for this booking');
  }

  // 1. Process mock payment
  const { success: paid, payment } = await paymentService.processMockPayment({
    bookingId: booking._id,
    userId: req.user._id,
    amount: booking.totalAmount,
    method: method || 'mock',
  });

  if (!paid) {
    return failure(res, 402, 'Payment failed', { failureReason: payment.failureReason });
  }

  // 2. Generate QR e-ticket
  const qrCode = await ticketService.generateQRCode(booking);

  // 3. Confirm booking
  booking.status = 'confirmed';
  booking.payment = payment._id;
  booking.qrCode = qrCode;
  await booking.save();

  // 4. Send confirmation notifications (booking + payment)
  await notificationService.notifyBookingConfirmation(booking, req.user);
  await notificationService.notifyPaymentConfirmation(booking, req.user, payment);

  return success(res, 200, 'Payment successful. Booking confirmed!', {
    booking,
    payment,
    qrCode,
  });
});

// @route GET /api/payments/:id
const getPaymentById = asyncHandler(async (req, res) => {
  const Payment = require('../models/Payment');
  const payment = await Payment.findById(req.params.id).populate('booking');
  if (!payment) return failure(res, 404, 'Payment not found');
  if (req.user.role === 'customer' && payment.user.toString() !== req.user._id.toString()) {
    return failure(res, 403, 'Not authorized');
  }
  return success(res, 200, 'Payment fetched', { payment });
});

module.exports = { payForBooking, getPaymentById };

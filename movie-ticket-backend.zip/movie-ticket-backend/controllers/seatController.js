const Seat = require('../models/Seat');
const { success, failure } = require('../utils/apiResponse');
const asyncHandler = require('../middleware/asyncHandler');

// @route GET /api/seats?screen=:screenId  - view the physical seat layout of a screen
const getSeatsByScreen = asyncHandler(async (req, res) => {
  const { screen } = req.query;
  if (!screen) return failure(res, 400, 'screen query parameter is required');
  const seats = await Seat.find({ screen, isActive: true }).sort({ row: 1, column: 1 });
  return success(res, 200, 'Seats fetched', { seats });
});

// @route PUT /api/seats/:id (manager/admin) - e.g. mark a seat inactive/broken, change type
const updateSeat = asyncHandler(async (req, res) => {
  const seat = await Seat.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  if (!seat) return failure(res, 404, 'Seat not found');
  return success(res, 200, 'Seat updated', { seat });
});

module.exports = { getSeatsByScreen, updateSeat };

const Movie = require('../models/Movie');
const { success, failure } = require('../utils/apiResponse');
const asyncHandler = require('../middleware/asyncHandler');

// @route POST /api/movies (admin/manager)
const createMovie = asyncHandler(async (req, res) => {
  const movie = await Movie.create(req.body);
  return success(res, 201, 'Movie created successfully', { movie });
});

// @route GET /api/movies?status=&genre=&search=&page=&limit=
const getMovies = asyncHandler(async (req, res) => {
  const { status, genre, search, page = 1, limit = 20 } = req.query;
  const filter = {};
  if (status) filter.status = status;
  if (genre) filter.genre = genre;
  if (search) filter.$text = { $search: search };

  const skip = (Number(page) - 1) * Number(limit);
  const [movies, total] = await Promise.all([
    Movie.find(filter).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
    Movie.countDocuments(filter),
  ]);

  return success(res, 200, 'Movies fetched', { movies }, { total, page: Number(page), limit: Number(limit) });
});

// @route GET /api/movies/:id
const getMovieById = asyncHandler(async (req, res) => {
  const movie = await Movie.findById(req.params.id);
  if (!movie) return failure(res, 404, 'Movie not found');
  return success(res, 200, 'Movie fetched', { movie });
});

// @route PUT /api/movies/:id (admin/manager)
const updateMovie = asyncHandler(async (req, res) => {
  const movie = await Movie.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  if (!movie) return failure(res, 404, 'Movie not found');
  return success(res, 200, 'Movie updated', { movie });
});

// @route DELETE /api/movies/:id (admin)
const deleteMovie = asyncHandler(async (req, res) => {
  const movie = await Movie.findByIdAndUpdate(req.params.id, { status: 'archived' }, { new: true });
  if (!movie) return failure(res, 404, 'Movie not found');
  return success(res, 200, 'Movie archived', { movie });
});

module.exports = { createMovie, getMovies, getMovieById, updateMovie, deleteMovie };

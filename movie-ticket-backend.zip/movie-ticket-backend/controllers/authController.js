const User = require('../models/User');
const generateToken = require('../utils/generateToken');
const { success, failure } = require('../utils/apiResponse');
const asyncHandler = require('../middleware/asyncHandler');

// @route POST /api/auth/register
// @access Public (role defaults to 'customer'; staff/manager/admin are created by admin via /api/auth/create-staff)
const register = asyncHandler(async (req, res) => {
  const { name, email, password, phone, favoriteGenres } = req.body;

  const existing = await User.findOne({ email });
  if (existing) return failure(res, 409, 'A user with this email already exists');

  const user = await User.create({
    name,
    email,
    password,
    phone,
    role: 'customer',
    preferences: { favoriteGenres: favoriteGenres || [] },
  });

  const token = generateToken({ id: user._id, role: user.role });

  return success(res, 201, 'Registered successfully', {
    user: { id: user._id, name: user.name, email: user.email, role: user.role },
    token,
  });
});

// @route POST /api/auth/create-staff  (admin only - creates staff/manager/admin accounts)
const createStaffUser = asyncHandler(async (req, res) => {
  const { name, email, password, phone, role, theatre } = req.body;

  const existing = await User.findOne({ email });
  if (existing) return failure(res, 409, 'A user with this email already exists');

  const user = await User.create({ name, email, password, phone, role, theatre });

  return success(res, 201, `${role} account created successfully`, {
    user: { id: user._id, name: user.name, email: user.email, role: user.role },
  });
});

// @route POST /api/auth/login
const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  const user = await User.findOne({ email }).select('+password');
  if (!user || !(await user.comparePassword(password))) {
    return failure(res, 401, 'Invalid email or password');
  }
  if (!user.isActive) {
    return failure(res, 403, 'This account has been deactivated');
  }

  const token = generateToken({ id: user._id, role: user.role });

  return success(res, 200, 'Login successful', {
    user: { id: user._id, name: user.name, email: user.email, role: user.role },
    token,
  });
});

// @route GET /api/auth/me
const getMe = asyncHandler(async (req, res) => {
  return success(res, 200, 'Current user profile', { user: req.user });
});

// @route PUT /api/auth/me
const updateMe = asyncHandler(async (req, res) => {
  const { name, phone, favoriteGenres } = req.body;
  if (name) req.user.name = name;
  if (phone) req.user.phone = phone;
  if (favoriteGenres) req.user.preferences.favoriteGenres = favoriteGenres;
  await req.user.save();
  return success(res, 200, 'Profile updated', { user: req.user });
});

module.exports = { register, login, getMe, updateMe, createStaffUser };

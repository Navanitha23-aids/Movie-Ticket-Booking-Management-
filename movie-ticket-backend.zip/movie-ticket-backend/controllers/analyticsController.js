const { success } = require('../utils/apiResponse');
const asyncHandler = require('../middleware/asyncHandler');
const analyticsService = require('../services/analyticsService');

// @route GET /api/analytics/dashboard  (admin/manager) - full dashboard summary in one call
const getDashboard = asyncHandler(async (req, res) => {
  const { from, to } = req.query;

  const [revenueSummary, revenueByShowType, topMovies, theatreOccupancy, statusBreakdown, slaMetrics, dailyTrend] =
    await Promise.all([
      analyticsService.getRevenueSummary({ from, to }),
      analyticsService.getRevenueByShowType(),
      analyticsService.getTopMovies(5),
      analyticsService.getTheatreOccupancy(),
      analyticsService.getBookingStatusBreakdown(),
      analyticsService.getSLAMetrics(),
      analyticsService.getDailyBookingTrend(14),
    ]);

  return success(res, 200, 'Analytics dashboard data fetched', {
    revenueSummary,
    revenueByShowType,
    topMovies,
    theatreOccupancy,
    statusBreakdown,
    slaMetrics,
    dailyTrend,
  });
});

const getRevenue = asyncHandler(async (req, res) => {
  const { from, to } = req.query;
  const summary = await analyticsService.getRevenueSummary({ from, to });
  return success(res, 200, 'Revenue summary fetched', { summary });
});

const getSLAReport = asyncHandler(async (req, res) => {
  const metrics = await analyticsService.getSLAMetrics();
  return success(res, 200, 'SLA report fetched', { metrics });
});

module.exports = { getDashboard, getRevenue, getSLAReport };

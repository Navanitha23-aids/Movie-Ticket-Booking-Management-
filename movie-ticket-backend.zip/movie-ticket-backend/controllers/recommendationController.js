const { success, failure } = require('../utils/apiResponse');
const asyncHandler = require('../middleware/asyncHandler');
const recommendationService = require('../services/recommendationService');

// @route GET /api/recommendations  (AI-based movie recommendation, personalized for logged-in user)
const getMyRecommendations = asyncHandler(async (req, res) => {
  const limit = parseInt(req.query.limit || '10', 10);
  const result = await recommendationService.getRecommendationsForUser(req.user._id, req.user, limit);
  return success(res, 200, 'Recommendations generated', result);
});

// @route GET /api/recommendations/trending  (public - trending/most-booked movies)
const getTrending = asyncHandler(async (req, res) => {
  const limit = parseInt(req.query.limit || '10', 10);
  const trending = await recommendationService.getTrendingMovies(limit);
  return success(res, 200, 'Trending movies fetched', { trending });
});

module.exports = { getMyRecommendations, getTrending };

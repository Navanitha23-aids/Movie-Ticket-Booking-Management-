const express = require('express');
const router = express.Router();

const { getTicket, verifyTicket } = require('../controllers/ticketController');
const { protect } = require('../middleware/authMiddleware');
const { authorize } = require('../middleware/roleMiddleware');
const { ROLES } = require('../config/constants');

router.use(protect);

router.get('/:bookingId', getTicket);
router.post('/verify', authorize(ROLES.STAFF, ROLES.MANAGER, ROLES.ADMIN), verifyTicket);

module.exports = router;

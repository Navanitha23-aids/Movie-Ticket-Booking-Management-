const express = require('express');
const router = express.Router();

const { getMyRecommendations, getTrending } = require('../controllers/recommendationController');
const { protect } = require('../middleware/authMiddleware');

router.get('/trending', getTrending); // public
router.get('/', protect, getMyRecommendations); // personalized, requires auth

module.exports = router;

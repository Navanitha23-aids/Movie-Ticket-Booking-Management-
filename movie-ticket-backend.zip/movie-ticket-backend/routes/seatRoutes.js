const express = require('express');
const router = express.Router();

const { getSeatsByScreen, updateSeat } = require('../controllers/seatController');
const { protect } = require('../middleware/authMiddleware');
const { authorize } = require('../middleware/roleMiddleware');
const { ROLES } = require('../config/constants');

router.get('/', getSeatsByScreen);
router.put('/:id', protect, authorize(ROLES.ADMIN, ROLES.MANAGER), updateSeat);

module.exports = router;

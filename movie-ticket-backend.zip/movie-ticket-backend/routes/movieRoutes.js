const express = require('express');
const { body } = require('express-validator');
const router = express.Router();

const { createMovie, getMovies, getMovieById, updateMovie, deleteMovie } = require('../controllers/movieController');
const { protect } = require('../middleware/authMiddleware');
const { authorize } = require('../middleware/roleMiddleware');
const { validate } = require('../middleware/validateMiddleware');
const { ROLES } = require('../config/constants');

router.get('/', getMovies);
router.get('/:id', getMovieById);

router.post(
  '/',
  protect,
  authorize(ROLES.ADMIN, ROLES.MANAGER),
  [
    body('title').trim().notEmpty(),
    body('description').notEmpty(),
    body('genre').isArray({ min: 1 }),
    body('language').isArray({ min: 1 }),
    body('duration').isInt({ min: 1 }),
    body('releaseDate').isISO8601(),
  ],
  validate,
  createMovie
);

router.put('/:id', protect, authorize(ROLES.ADMIN, ROLES.MANAGER), updateMovie);
router.delete('/:id', protect, authorize(ROLES.ADMIN), deleteMovie);

module.exports = router;

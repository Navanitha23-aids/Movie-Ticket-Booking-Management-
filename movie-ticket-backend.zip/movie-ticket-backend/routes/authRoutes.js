const express = require('express');
const { body } = require('express-validator');
const router = express.Router();

const { register, login, getMe, updateMe, createStaffUser } = require('../controllers/authController');
const { protect } = require('../middleware/authMiddleware');
const { authorize } = require('../middleware/roleMiddleware');
const { validate } = require('../middleware/validateMiddleware');
const { ROLES } = require('../config/constants');

router.post(
  '/register',
  [
    body('name').trim().notEmpty().withMessage('Name is required'),
    body('email').isEmail().withMessage('Valid email is required'),
    body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
  ],
  validate,
  register
);

router.post(
  '/login',
  [body('email').isEmail().withMessage('Valid email is required'), body('password').notEmpty().withMessage('Password is required')],
  validate,
  login
);

router.post(
  '/create-staff',
  protect,
  authorize(ROLES.ADMIN),
  [
    body('name').trim().notEmpty(),
    body('email').isEmail(),
    body('password').isLength({ min: 6 }),
    body('role').isIn([ROLES.STAFF, ROLES.MANAGER, ROLES.ADMIN]),
  ],
  validate,
  createStaffUser
);

router.get('/me', protect, getMe);
router.put('/me', protect, updateMe);

module.exports = router;

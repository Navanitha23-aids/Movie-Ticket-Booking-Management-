const express = require('express');
const { body } = require('express-validator');
const router = express.Router();

const { createTheatre, getTheatres, getTheatreById, updateTheatre, deleteTheatre } = require('../controllers/theatreController');
const { protect } = require('../middleware/authMiddleware');
const { authorize } = require('../middleware/roleMiddleware');
const { validate } = require('../middleware/validateMiddleware');
const { ROLES } = require('../config/constants');

router.get('/', getTheatres);
router.get('/:id', getTheatreById);

router.post(
  '/',
  protect,
  authorize(ROLES.ADMIN, ROLES.MANAGER),
  [
    body('name').trim().notEmpty(),
    body('location.address').notEmpty(),
    body('location.city').notEmpty(),
    body('location.state').notEmpty(),
  ],
  validate,
  createTheatre
);

router.put('/:id', protect, authorize(ROLES.ADMIN, ROLES.MANAGER), updateTheatre);
router.delete('/:id', protect, authorize(ROLES.ADMIN), deleteTheatre);

module.exports = router;

const express = require('express');
const { body } = require('express-validator');
const router = express.Router();

const {
  createShow,
  getShows,
  getShowById,
  checkAvailability,
  getSeatRecommendation,
  updateShow,
  cancelShow,
} = require('../controllers/showController');
const { protect } = require('../middleware/authMiddleware');
const { authorize } = require('../middleware/roleMiddleware');
const { validate } = require('../middleware/validateMiddleware');
const { ROLES, SHOW_TYPES } = require('../config/constants');

router.get('/', getShows);
router.get('/:id', getShowById);
router.get('/:id/availability', checkAvailability);
router.get('/:id/seat-recommendation', getSeatRecommendation);

router.post(
  '/',
  protect,
  authorize(ROLES.ADMIN, ROLES.MANAGER),
  [
    body('movie').notEmpty(),
    body('theatre').notEmpty(),
    body('screen').notEmpty(),
    body('showType').isIn(SHOW_TYPES),
    body('date').isISO8601(),
    body('startTime').isISO8601(),
    body('endTime').isISO8601(),
    body('basePrice').isFloat({ min: 0 }),
  ],
  validate,
  createShow
);

router.put('/:id', protect, authorize(ROLES.ADMIN, ROLES.MANAGER), updateShow);
router.post('/:id/cancel', protect, authorize(ROLES.ADMIN, ROLES.MANAGER), cancelShow);

module.exports = router;

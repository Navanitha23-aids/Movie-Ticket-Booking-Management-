const express = require('express');
const { body } = require('express-validator');
const router = express.Router();

const { createScreen, getScreens, getScreenById, updateScreen, deleteScreen } = require('../controllers/screenController');
const { protect } = require('../middleware/authMiddleware');
const { authorize } = require('../middleware/roleMiddleware');
const { validate } = require('../middleware/validateMiddleware');
const { ROLES, SHOW_TYPES } = require('../config/constants');

router.get('/', getScreens);
router.get('/:id', getScreenById);

router.post(
  '/',
  protect,
  authorize(ROLES.ADMIN, ROLES.MANAGER),
  [
    body('theatre').notEmpty(),
    body('name').trim().notEmpty(),
    body('screenType').isIn(SHOW_TYPES),
    body('totalRows').isInt({ min: 1 }),
    body('seatsPerRow').isInt({ min: 1 }),
  ],
  validate,
  createScreen
);

router.put('/:id', protect, authorize(ROLES.ADMIN, ROLES.MANAGER), updateScreen);
router.delete('/:id', protect, authorize(ROLES.ADMIN), deleteScreen);

module.exports = router;

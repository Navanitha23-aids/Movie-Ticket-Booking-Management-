const express = require('express');
const router = express.Router();

const {
  getBookingQuote,
  submitBookingRequest,
  getBookingById,
  getMyBookings,
  getAllBookings,
  cancelBooking,
} = require('../controllers/bookingController');
const { protect } = require('../middleware/authMiddleware');
const { authorize } = require('../middleware/roleMiddleware');
const { ROLES } = require('../config/constants');

router.use(protect); // all booking routes require authentication

router.post('/quote', getBookingQuote); // feature 3: calculate booking cost
router.post('/', submitBookingRequest); // feature 1 + 7: submit / process booking request
router.get('/my', getMyBookings); // feature 6: customer's own bookings
router.get('/', authorize(ROLES.STAFF, ROLES.MANAGER, ROLES.ADMIN), getAllBookings); // staff view all
router.get('/:id', getBookingById); // feature 6: view booking details
router.post('/:id/cancel', cancelBooking); // cancellation + auto seat release

module.exports = router;

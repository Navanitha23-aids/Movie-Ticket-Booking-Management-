const express = require('express');
const router = express.Router();

const { getDashboard, getRevenue, getSLAReport } = require('../controllers/analyticsController');
const { protect } = require('../middleware/authMiddleware');
const { authorize } = require('../middleware/roleMiddleware');
const { ROLES } = require('../config/constants');

router.use(protect, authorize(ROLES.ADMIN, ROLES.MANAGER));

router.get('/dashboard', getDashboard);
router.get('/revenue', getRevenue);
router.get('/sla', getSLAReport);

module.exports = router;

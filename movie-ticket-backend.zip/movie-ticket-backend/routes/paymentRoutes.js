const express = require('express');
const router = express.Router();

const { payForBooking, getPaymentById } = require('../controllers/paymentController');
const { protect } = require('../middleware/authMiddleware');

router.use(protect);

router.post('/pay', payForBooking); // mock payment -> confirms booking, feature 4 + 8
router.get('/:id', getPaymentById);

module.exports = router;

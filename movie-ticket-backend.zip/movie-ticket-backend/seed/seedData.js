/**
 * Seed / demo data script.
 * Usage: npm run seed
 * Wipes existing collections and populates realistic demo data:
 *  users (admin, manager, staff, customers), movies, theatres, screens,
 *  seats (auto-generated), and shows across Regular/3D/IMAX/VIP.
 */
require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('../config/db');

const User = require('../models/User');
const Movie = require('../models/Movie');
const Theatre = require('../models/Theatre');
const Screen = require('../models/Screen');
const Seat = require('../models/Seat');
const Show = require('../models/Show');
const Booking = require('../models/Booking');
const Payment = require('../models/Payment');
const Notification = require('../models/Notification');

const { generateSeatLayout } = require('../controllers/screenController');

const seed = async () => {
  await connectDB();
  console.log('Clearing existing data...');
  await Promise.all([
    User.deleteMany({}),
    Movie.deleteMany({}),
    Theatre.deleteMany({}),
    Screen.deleteMany({}),
    Seat.deleteMany({}),
    Show.deleteMany({}),
    Booking.deleteMany({}),
    Payment.deleteMany({}),
    Notification.deleteMany({}),
  ]);

  console.log('Creating users...');
  const admin = await User.create({
    name: 'Alice Admin',
    email: 'admin@movieapp.com',
    password: 'Admin@123',
    role: 'admin',
    phone: '9000000001',
  });

  const manager = await User.create({
    name: 'Mark Manager',
    email: 'manager@movieapp.com',
    password: 'Manager@123',
    role: 'manager',
    phone: '9000000002',
  });

  const staff = await User.create({
    name: 'Sam Staff',
    email: 'staff@movieapp.com',
    password: 'Staff@123',
    role: 'staff',
    phone: '9000000003',
  });

  const customer1 = await User.create({
    name: 'Chris Customer',
    email: 'customer1@movieapp.com',
    password: 'Customer@123',
    role: 'customer',
    phone: '9000000004',
    preferences: { favoriteGenres: ['Action', 'Sci-Fi'] },
  });

  const customer2 = await User.create({
    name: 'Priya Patel',
    email: 'customer2@movieapp.com',
    password: 'Customer@123',
    role: 'customer',
    phone: '9000000005',
    preferences: { favoriteGenres: ['Romance', 'Drama'] },
  });

  console.log('Creating movies...');
  const movies = await Movie.insertMany([
    {
      title: 'Galactic Frontier',
      description: 'A crew of explorers ventures beyond known space to find a new home for humanity.',
      genre: ['Action', 'Sci-Fi'],
      language: ['English', 'Hindi'],
      duration: 148,
      releaseDate: new Date('2026-06-01'),
      rating: 8.2,
      censorRating: 'UA',
      cast: ['Jordan Vega', 'Mia Chen'],
      director: 'Ravi Menon',
      status: 'now_showing',
      popularityScore: 9.1,
    },
    {
      title: 'Monsoon Melody',
      description: 'Two musicians from rival families fall in love during the monsoon festival.',
      genre: ['Romance', 'Drama', 'Musical'],
      language: ['Hindi', 'Tamil'],
      duration: 132,
      releaseDate: new Date('2026-05-15'),
      rating: 7.6,
      censorRating: 'U',
      cast: ['Aditi Rao', 'Karan Singh'],
      director: 'Meera Iyer',
      status: 'now_showing',
      popularityScore: 7.4,
    },
    {
      title: 'Shadow Protocol',
      description: 'An elite agent must stop a rogue AI from taking over global infrastructure.',
      genre: ['Action', 'Thriller'],
      language: ['English'],
      duration: 121,
      releaseDate: new Date('2026-07-10'),
      rating: 8.0,
      censorRating: 'A',
      cast: ['Ethan Cole', 'Nina Osei'],
      director: 'Daniel Kim',
      status: 'now_showing',
      popularityScore: 8.7,
    },
    {
      title: 'Laugh Riot',
      description: 'A chaotic family road trip turns into the funniest disaster of the year.',
      genre: ['Comedy', 'Family'],
      language: ['English', 'Hindi'],
      duration: 105,
      releaseDate: new Date('2026-04-20'),
      rating: 7.1,
      censorRating: 'U',
      cast: ['Sam Wheeler', 'Devika Nair'],
      director: 'Anjali Rao',
      status: 'now_showing',
      popularityScore: 6.5,
    },
    {
      title: 'The Last Horizon',
      description: 'An upcoming epic about humanity\'s final stand against a cosmic threat.',
      genre: ['Sci-Fi', 'Drama'],
      language: ['English'],
      duration: 155,
      releaseDate: new Date('2026-12-25'),
      rating: 0,
      censorRating: 'UA',
      cast: ['Olivia Park', 'Marcus Reed'],
      director: 'Ravi Menon',
      status: 'upcoming',
      popularityScore: 5.0,
    },
  ]);

  console.log('Creating theatres...');
  const theatre1 = await Theatre.create({
    name: 'Cineplex Grand Coimbatore',
    location: { address: '100 RS Puram Main Rd', city: 'Coimbatore', state: 'Tamil Nadu', pincode: '641002' },
    contact: '0422-1234567',
    amenities: ['Parking', 'Food Court', 'Wheelchair Access'],
    manager: manager._id,
  });

  const theatre2 = await Theatre.create({
    name: 'StarView Cinemas Gandhipuram',
    location: { address: '45 Cross Cut Rd', city: 'Coimbatore', state: 'Tamil Nadu', pincode: '641012' },
    contact: '0422-7654321',
    amenities: ['Parking', 'IMAX Screen', 'Dolby Atmos'],
    manager: manager._id,
  });

  manager.theatre = theatre1._id;
  staff.theatre = theatre1._id;
  await manager.save();
  await staff.save();

  console.log('Creating screens + seat layouts...');
  const screenRegular = await Screen.create({
    theatre: theatre1._id,
    name: 'Screen 1',
    screenType: 'Regular',
    totalRows: 8,
    seatsPerRow: 10,
    totalSeats: 80,
  });
  await generateSeatLayout(screenRegular);

  const screen3D = await Screen.create({
    theatre: theatre1._id,
    name: 'Screen 2 (3D)',
    screenType: '3D',
    totalRows: 8,
    seatsPerRow: 10,
    totalSeats: 80,
  });
  await generateSeatLayout(screen3D);

  const screenIMAX = await Screen.create({
    theatre: theatre2._id,
    name: 'IMAX Auditorium',
    screenType: 'IMAX',
    totalRows: 10,
    seatsPerRow: 12,
    totalSeats: 120,
  });
  await generateSeatLayout(screenIMAX);

  const screenVIP = await Screen.create({
    theatre: theatre2._id,
    name: 'VIP Lounge Screen',
    screenType: 'VIP',
    totalRows: 5,
    seatsPerRow: 8,
    totalSeats: 40,
  });
  await generateSeatLayout(screenVIP);

  console.log('Creating shows...');
  const today = new Date();
  const mkTime = (daysFromNow, hour, minute = 0) => {
    const d = new Date(today);
    d.setDate(d.getDate() + daysFromNow);
    d.setHours(hour, minute, 0, 0);
    return d;
  };
  const mkDate = (daysFromNow) => {
    const d = new Date(today);
    d.setDate(d.getDate() + daysFromNow);
    d.setHours(0, 0, 0, 0);
    return d;
  };

  const shows = [
    {
      movie: movies[0]._id, theatre: theatre1._id, screen: screenRegular._id, showType: 'Regular',
      date: mkDate(0), startTime: mkTime(0, 14, 0), endTime: mkTime(0, 16, 30), basePrice: 200, totalSeats: 80,
    },
    {
      movie: movies[0]._id, theatre: theatre1._id, screen: screen3D._id, showType: '3D',
      date: mkDate(0), startTime: mkTime(0, 19, 0), endTime: mkTime(0, 21, 30), basePrice: 320, totalSeats: 80,
    },
    {
      movie: movies[2]._id, theatre: theatre2._id, screen: screenIMAX._id, showType: 'IMAX',
      date: mkDate(1), startTime: mkTime(1, 20, 0), endTime: mkTime(1, 22, 5), basePrice: 450, totalSeats: 120,
    },
    {
      movie: movies[1]._id, theatre: theatre2._id, screen: screenVIP._id, showType: 'VIP',
      date: mkDate(1), startTime: mkTime(1, 18, 30), endTime: mkTime(1, 20, 45), basePrice: 600, totalSeats: 40,
    },
    {
      movie: movies[3]._id, theatre: theatre1._id, screen: screenRegular._id, showType: 'Regular',
      date: mkDate(2), startTime: mkTime(2, 11, 0), endTime: mkTime(2, 12, 50), basePrice: 180, totalSeats: 80,
    },
    {
      movie: movies[2]._id, theatre: theatre1._id, screen: screen3D._id, showType: '3D',
      date: mkDate(2), startTime: mkTime(2, 22, 0), endTime: mkTime(2, 23, 55), basePrice: 340, totalSeats: 80,
    },
  ];

  const createdShows = await Show.insertMany(shows);

  // Pre-book a few seats on the first show to demo dynamic pricing / availability
  await Show.findByIdAndUpdate(createdShows[0]._id, {
    $push: { bookedSeats: { $each: ['A1', 'A2', 'A3', 'B5', 'B6', 'C1', 'C2', 'C3', 'C4'] } },
  });

  console.log('\n===== SEED COMPLETE =====');
  console.log('Demo login credentials:');
  console.log('  Admin:    admin@movieapp.com / Admin@123');
  console.log('  Manager:  manager@movieapp.com / Manager@123');
  console.log('  Staff:    staff@movieapp.com / Staff@123');
  console.log('  Customer: customer1@movieapp.com / Customer@123');
  console.log('  Customer: customer2@movieapp.com / Customer@123');
  console.log('==========================\n');

  await mongoose.connection.close();
  process.exit(0);
};

seed().catch((err) => {
  console.error('Seed failed:', err);
  process.exit(1);
});

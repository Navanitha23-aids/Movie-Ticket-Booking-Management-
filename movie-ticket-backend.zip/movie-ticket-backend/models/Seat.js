const mongoose = require('mongoose');
const { SEAT_TYPES } = require('../config/constants');

// Seat is a template/layout entity belonging to a screen (physical seat map).
// Per-show occupancy is tracked on the Show model (bookedSeats) to keep
// seat availability atomic per show without cross-document locking.
const seatSchema = new mongoose.Schema(
  {
    screen: { type: mongoose.Schema.Types.ObjectId, ref: 'Screen', required: true },
    seatNumber: { type: String, required: true }, // e.g. "A1"
    row: { type: String, required: true },
    column: { type: Number, required: true },
    seatType: { type: String, enum: SEAT_TYPES, default: 'Regular' },
    basePriceMultiplier: { type: Number, default: 1 }, // e.g. Premium 1.5x, VIP 2x
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

seatSchema.index({ screen: 1, seatNumber: 1 }, { unique: true });

module.exports = mongoose.model('Seat', seatSchema);

const mongoose = require('mongoose');
const { PAYMENT_STATUS } = require('../config/constants');

const paymentSchema = new mongoose.Schema(
  {
    booking: { type: mongoose.Schema.Types.ObjectId, ref: 'Booking', required: true },
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    amount: { type: Number, required: true, min: 0 },
    method: { type: String, enum: ['card', 'upi', 'netbanking', 'wallet', 'mock'], default: 'mock' },
    status: { type: String, enum: Object.values(PAYMENT_STATUS), default: 'pending' },
    transactionId: { type: String, required: true, unique: true },
    failureReason: { type: String },
    refundedAt: { type: Date },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Payment', paymentSchema);

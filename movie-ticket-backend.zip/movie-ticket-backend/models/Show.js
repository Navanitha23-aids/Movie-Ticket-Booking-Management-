const mongoose = require('mongoose');
const { SHOW_TYPES } = require('../config/constants');

const showSchema = new mongoose.Schema(
  {
    movie: { type: mongoose.Schema.Types.ObjectId, ref: 'Movie', required: true },
    theatre: { type: mongoose.Schema.Types.ObjectId, ref: 'Theatre', required: true },
    screen: { type: mongoose.Schema.Types.ObjectId, ref: 'Screen', required: true },
    showType: { type: String, enum: SHOW_TYPES, required: true },
    date: { type: Date, required: true }, // date-only (midnight) for querying by day
    startTime: { type: Date, required: true },
    endTime: { type: Date, required: true },
    basePrice: { type: Number, required: true, min: 0 },
    totalSeats: { type: Number, required: true },
    // Seat numbers currently booked/held for THIS show - atomic array updates
    // prevent double booking (see bookingService for $nin / $addToSet usage).
    bookedSeats: [{ type: String }],
    heldSeats: [
      {
        seatNumber: { type: String },
        heldBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
        holdExpiresAt: { type: Date },
      },
    ],
    status: { type: String, enum: ['scheduled', 'ongoing', 'completed', 'cancelled'], default: 'scheduled' },
  },
  { timestamps: true }
);

showSchema.index({ movie: 1, theatre: 1, date: 1 });
showSchema.index({ screen: 1, startTime: 1 });

showSchema.virtual('availableSeatCount').get(function () {
  return this.totalSeats - this.bookedSeats.length;
});

showSchema.set('toJSON', { virtuals: true });
showSchema.set('toObject', { virtuals: true });

module.exports = mongoose.model('Show', showSchema);

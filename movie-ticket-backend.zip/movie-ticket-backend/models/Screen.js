const mongoose = require('mongoose');
const { SHOW_TYPES } = require('../config/constants');

const screenSchema = new mongoose.Schema(
  {
    theatre: { type: mongoose.Schema.Types.ObjectId, ref: 'Theatre', required: true },
    name: { type: String, required: [true, 'Screen name is required'], trim: true },
    screenType: { type: String, enum: SHOW_TYPES, default: 'Regular' },
    totalRows: { type: Number, required: true, min: 1 },
    seatsPerRow: { type: Number, required: true, min: 1 },
    totalSeats: { type: Number, required: true, min: 1 },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

screenSchema.index({ theatre: 1 });

module.exports = mongoose.model('Screen', screenSchema);

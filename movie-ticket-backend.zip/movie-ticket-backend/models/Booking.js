const mongoose = require('mongoose');
const { BOOKING_STATUS } = require('../config/constants');

const bookingSchema = new mongoose.Schema(
  {
    bookingCode: { type: String, required: true, unique: true },
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    show: { type: mongoose.Schema.Types.ObjectId, ref: 'Show', required: true },
    movie: { type: mongoose.Schema.Types.ObjectId, ref: 'Movie', required: true },
    theatre: { type: mongoose.Schema.Types.ObjectId, ref: 'Theatre', required: true },
    screen: { type: mongoose.Schema.Types.ObjectId, ref: 'Screen', required: true },
    seats: [{ type: String, required: true }], // seat numbers e.g. ["A1","A2"]
    showType: { type: String, required: true },
    numSeats: { type: Number, required: true, min: 1 },
    pricePerSeatBreakdown: [
      {
        seatNumber: String,
        seatType: String,
        price: Number,
      },
    ],
    subtotal: { type: Number, required: true },
    dynamicPricingSurcharge: { type: Number, default: 0 },
    taxes: { type: Number, default: 0 },
    totalAmount: { type: Number, required: true },
    status: { type: String, enum: Object.values(BOOKING_STATUS), default: 'pending' },
    payment: { type: mongoose.Schema.Types.ObjectId, ref: 'Payment' },
    qrCode: { type: String }, // base64 data URL of QR e-ticket
    ticketVerified: { type: Boolean, default: false },
    ticketVerifiedAt: { type: Date },

    // Routing metadata (feature 10: route booking based on show type)
    routeQueue: { type: String },
    priority: { type: String, enum: ['normal', 'high', 'urgent'], default: 'normal' },

    // SLA / escalation (feature 9)
    slaDeadline: { type: Date, required: true }, // payment must complete by this time
    escalationDeadline: { type: Date, required: true },
    isEscalated: { type: Boolean, default: false },
    escalatedAt: { type: Date },
    slaBreachedStage: { type: String }, // 'payment' | 'confirmation'

    cancelledAt: { type: Date },
    cancellationReason: { type: String },
    reminderSent: { type: Boolean, default: false },
  },
  { timestamps: true }
);

bookingSchema.index({ user: 1, createdAt: -1 });
bookingSchema.index({ show: 1 });
bookingSchema.index({ status: 1, slaDeadline: 1 });

module.exports = mongoose.model('Booking', bookingSchema);

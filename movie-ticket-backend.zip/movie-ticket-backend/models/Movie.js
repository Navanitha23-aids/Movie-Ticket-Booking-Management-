const mongoose = require('mongoose');
const { MOVIE_STATUS } = require('../config/constants');

const movieSchema = new mongoose.Schema(
  {
    title: { type: String, required: [true, 'Movie title is required'], trim: true },
    description: { type: String, required: [true, 'Description is required'] },
    genre: [{ type: String, required: true }],
    language: [{ type: String, required: true }],
    duration: { type: Number, required: [true, 'Duration (minutes) is required'], min: 1 },
    releaseDate: { type: Date, required: true },
    rating: { type: Number, min: 0, max: 10, default: 0 }, // avg rating
    censorRating: { type: String, enum: ['U', 'UA', 'A', 'S'], default: 'UA' },
    poster: { type: String, default: '' },
    cast: [{ type: String }],
    director: { type: String },
    status: { type: String, enum: MOVIE_STATUS, default: 'now_showing' },
    popularityScore: { type: Number, default: 0 }, // used by recommendation engine
  },
  { timestamps: true }
);

movieSchema.index({ title: 'text', genre: 1, status: 1 });

module.exports = mongoose.model('Movie', movieSchema);

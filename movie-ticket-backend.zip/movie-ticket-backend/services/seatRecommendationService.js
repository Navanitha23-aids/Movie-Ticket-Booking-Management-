/**
 * Smart Seat Recommendation Service
 * Suggests the best available contiguous seats for a group, preferring:
 *  - center rows (better viewing experience)
 *  - contiguous seats (so a group can sit together)
 *  - falls back to best-effort nearest seats if no contiguous block exists
 */

const parseSeat = (seatNumber) => {
  const match = seatNumber.match(/^([A-Za-z]+)(\d+)$/);
  if (!match) return null;
  return { row: match[1], col: parseInt(match[2], 10) };
};

/**
 * @param {Array} allSeats - full seat layout for the screen [{seatNumber, row, column, seatType}]
 * @param {Array} bookedSeatNumbers - seat numbers already booked for this show
 * @param {Number} numSeats - how many seats the customer wants
 */
const recommendSeats = (allSeats, bookedSeatNumbers, numSeats) => {
  const bookedSet = new Set(bookedSeatNumbers);
  const available = allSeats.filter((s) => !bookedSet.has(s.seatNumber));

  if (available.length < numSeats) {
    return { recommended: [], reason: 'Not enough available seats for this show' };
  }

  // Group available seats by row
  const rowGroups = {};
  available.forEach((s) => {
    if (!rowGroups[s.row]) rowGroups[s.row] = [];
    rowGroups[s.row].push(s);
  });

  const allRows = Object.keys(rowGroups).sort();
  const centerRowIndex = Math.floor(allRows.length / 2);
  // Order rows by proximity to center row (best viewing experience first)
  const rowsByPreference = [...allRows].sort(
    (a, b) => Math.abs(allRows.indexOf(a) - centerRowIndex) - Math.abs(allRows.indexOf(b) - centerRowIndex)
  );

  // Try to find a contiguous block within a single preferred row
  for (const row of rowsByPreference) {
    const seatsInRow = rowGroups[row].sort((a, b) => a.column - b.column);
    for (let i = 0; i <= seatsInRow.length - numSeats; i++) {
      const block = seatsInRow.slice(i, i + numSeats);
      const isContiguous = block.every((seat, idx) => idx === 0 || seat.column === block[idx - 1].column + 1);
      if (isContiguous) {
        return {
          recommended: block.map((s) => s.seatNumber),
          reason: `Contiguous seats in row ${row} (near center for optimal viewing)`,
        };
      }
    }
  }

  // Fallback: no contiguous block available anywhere, return best-effort closest seats
  const fallback = available
    .slice()
    .sort((a, b) => Math.abs(allRows.indexOf(a.row) - centerRowIndex) - Math.abs(allRows.indexOf(b.row) - centerRowIndex))
    .slice(0, numSeats)
    .map((s) => s.seatNumber);

  return {
    recommended: fallback,
    reason: 'No contiguous block available; returning closest best-effort seats',
  };
};

module.exports = { recommendSeats, parseSeat };

/**
 * Admin Analytics Dashboard Service - aggregation queries for reporting.
 */
const Booking = require('../models/Booking');
const Show = require('../models/Show');
const Movie = require('../models/Movie');

const getRevenueSummary = async ({ from, to } = {}) => {
  const match = { status: 'confirmed' };
  if (from || to) {
    match.createdAt = {};
    if (from) match.createdAt.$gte = new Date(from);
    if (to) match.createdAt.$lte = new Date(to);
  }

  const [summary] = await Booking.aggregate([
    { $match: match },
    {
      $group: {
        _id: null,
        totalRevenue: { $sum: '$totalAmount' },
        totalBookings: { $sum: 1 },
        totalSeatsSold: { $sum: '$numSeats' },
        avgBookingValue: { $avg: '$totalAmount' },
      },
    },
  ]);

  return (
    summary || { totalRevenue: 0, totalBookings: 0, totalSeatsSold: 0, avgBookingValue: 0 }
  );
};

const getRevenueByShowType = async () => {
  return Booking.aggregate([
    { $match: { status: 'confirmed' } },
    { $group: { _id: '$showType', revenue: { $sum: '$totalAmount' }, bookings: { $sum: 1 } } },
    { $sort: { revenue: -1 } },
  ]);
};

const getTopMovies = async (limit = 5) => {
  return Booking.aggregate([
    { $match: { status: 'confirmed' } },
    { $group: { _id: '$movie', revenue: { $sum: '$totalAmount' }, ticketsSold: { $sum: '$numSeats' } } },
    { $sort: { revenue: -1 } },
    { $limit: limit },
    { $lookup: { from: 'movies', localField: '_id', foreignField: '_id', as: 'movie' } },
    { $unwind: '$movie' },
    { $project: { movie: { title: 1, genre: 1, poster: 1 }, revenue: 1, ticketsSold: 1 } },
  ]);
};

const getTheatreOccupancy = async () => {
  return Show.aggregate([
    { $match: { status: { $in: ['scheduled', 'ongoing', 'completed'] } } },
    {
      $group: {
        _id: '$theatre',
        totalSeats: { $sum: '$totalSeats' },
        totalBooked: { $sum: { $size: '$bookedSeats' } },
      },
    },
    {
      $project: {
        totalSeats: 1,
        totalBooked: 1,
        occupancyRate: {
          $cond: [{ $eq: ['$totalSeats', 0] }, 0, { $multiply: [{ $divide: ['$totalBooked', '$totalSeats'] }, 100] }],
        },
      },
    },
    { $lookup: { from: 'theatres', localField: '_id', foreignField: '_id', as: 'theatre' } },
    { $unwind: '$theatre' },
    { $project: { 'theatre.name': 1, 'theatre.location': 1, totalSeats: 1, totalBooked: 1, occupancyRate: 1 } },
  ]);
};

const getBookingStatusBreakdown = async () => {
  return Booking.aggregate([{ $group: { _id: '$status', count: { $sum: 1 } } }]);
};

const getSLAMetrics = async () => {
  const [escalated, expired, total] = await Promise.all([
    Booking.countDocuments({ isEscalated: true }),
    Booking.countDocuments({ status: 'expired' }),
    Booking.countDocuments({}),
  ]);
  return {
    totalBookings: total,
    escalatedBookings: escalated,
    expiredBookings: expired,
    escalationRate: total ? Math.round((escalated / total) * 10000) / 100 : 0,
    expiryRate: total ? Math.round((expired / total) * 10000) / 100 : 0,
  };
};

const getDailyBookingTrend = async (days = 14) => {
  const since = new Date();
  since.setDate(since.getDate() - days);

  return Booking.aggregate([
    { $match: { createdAt: { $gte: since } } },
    {
      $group: {
        _id: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } },
        bookings: { $sum: 1 },
        revenue: { $sum: { $cond: [{ $eq: ['$status', 'confirmed'] }, '$totalAmount', 0] } },
      },
    },
    { $sort: { _id: 1 } },
  ]);
};

module.exports = {
  getRevenueSummary,
  getRevenueByShowType,
  getTopMovies,
  getTheatreOccupancy,
  getBookingStatusBreakdown,
  getSLAMetrics,
  getDailyBookingTrend,
};

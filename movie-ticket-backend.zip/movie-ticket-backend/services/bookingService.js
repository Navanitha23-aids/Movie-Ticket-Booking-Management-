/**
 * Booking Service - core business logic for the booking lifecycle.
 * Double-booking prevention strategy:
 *   Show.bookedSeats is updated with a single ATOMIC findOneAndUpdate using
 *   a condition `bookedSeats: { $nin: requestedSeats }`. MongoDB guarantees
 *   document-level update atomicity, so if two requests race for the same
 *   seat, only one findOneAndUpdate will match (the seat won't be $nin
 *   anymore for the second request) and the second call returns null,
 *   which we treat as a conflict. This works reliably even on a standalone
 *   MongoDB instance (no replica set / multi-document transaction required).
 */
const mongoose = require('mongoose');
const Show = require('../models/Show');
const Seat = require('../models/Seat');
const Booking = require('../models/Booking');
const Screen = require('../models/Screen');

const pricingService = require('./pricingService');
const routingService = require('./routingService');
const { generateBookingCode } = require('../utils/generateCode');

class BookingConflictError extends Error {
  constructor(message, seats) {
    super(message);
    this.statusCode = 409;
    this.conflictSeats = seats;
  }
}

class ValidationError extends Error {
  constructor(message) {
    super(message);
    this.statusCode = 400;
  }
}

/**
 * Atomically reserves seats on a Show document. Throws BookingConflictError
 * if any requested seat is already booked by the time this runs.
 */
const reserveSeatsAtomically = async (showId, seatNumbers) => {
  const updatedShow = await Show.findOneAndUpdate(
    {
      _id: showId,
      status: 'scheduled',
      bookedSeats: { $nin: seatNumbers }, // NONE of requested seats may already be booked
    },
    { $push: { bookedSeats: { $each: seatNumbers } } },
    { new: true }
  );

  if (!updatedShow) {
    // Either show not found/not scheduled, or (most likely) a seat collision.
    const currentShow = await Show.findById(showId);
    if (!currentShow) throw new ValidationError('Show not found');
    if (currentShow.status !== 'scheduled') throw new ValidationError('Show is not open for booking');

    const conflicts = seatNumbers.filter((s) => currentShow.bookedSeats.includes(s));
    throw new BookingConflictError(
      `Seat(s) already booked: ${conflicts.join(', ')}. Please choose different seats.`,
      conflicts
    );
  }

  return updatedShow;
};

/** Releases seats back to the pool (used on cancellation / SLA expiry) */
const releaseSeats = async (showId, seatNumbers) => {
  return Show.findByIdAndUpdate(
    showId,
    { $pull: { bookedSeats: { $in: seatNumbers } } },
    { new: true }
  );
};

/**
 * Full "submit + process booking" flow:
 *  1. Validate show + seats exist and are available
 *  2. Calculate dynamic price
 *  3. Atomically reserve seats (double-booking prevention)
 *  4. Create Booking in 'pending' status with SLA deadlines
 *  5. Attach routing metadata based on show type
 */
const createBooking = async ({ userId, showId, seatNumbers }) => {
  if (!seatNumbers || seatNumbers.length === 0) {
    throw new ValidationError('At least one seat must be selected');
  }
  const uniqueSeats = [...new Set(seatNumbers)];
  if (uniqueSeats.length !== seatNumbers.length) {
    throw new ValidationError('Duplicate seats in request');
  }

  const show = await Show.findById(showId).populate('movie').populate('theatre').populate('screen');
  if (!show) throw new ValidationError('Show not found');
  if (show.status !== 'scheduled') throw new ValidationError('Show is not currently open for booking');
  if (new Date(show.startTime) <= new Date()) throw new ValidationError('Cannot book a show that has already started');

  // Validate seats belong to this screen and fetch their type/multiplier
  const seatDocs = await Seat.find({ screen: show.screen._id, seatNumber: { $in: uniqueSeats }, isActive: true });
  if (seatDocs.length !== uniqueSeats.length) {
    const foundNumbers = seatDocs.map((s) => s.seatNumber);
    const missing = uniqueSeats.filter((s) => !foundNumbers.includes(s));
    throw new ValidationError(`Invalid seat number(s) for this screen: ${missing.join(', ')}`);
  }

  // Pre-check availability quickly (fast fail before the atomic write, still re-checked atomically)
  const alreadyBooked = uniqueSeats.filter((s) => show.bookedSeats.includes(s));
  if (alreadyBooked.length > 0) {
    throw new BookingConflictError(`Seat(s) already booked: ${alreadyBooked.join(', ')}`, alreadyBooked);
  }

  // Calculate cost using CURRENT occupancy (demand-based dynamic pricing)
  const costCalc = pricingService.calculateBookingCost({ show, seatsInfo: seatDocs });

  // Atomically reserve seats - this is the double-booking safety net
  await reserveSeatsAtomically(showId, uniqueSeats);

  try {
    const now = new Date();
    const paymentSlaMinutes = parseInt(process.env.BOOKING_PAYMENT_SLA_MINUTES || '10', 10);
    const escalationSlaMinutes = parseInt(process.env.BOOKING_ESCALATION_SLA_MINUTES || '15', 10);

    const { routeQueue, priority } = routingService.routeBookingByShowType(show.showType);

    const booking = await Booking.create({
      bookingCode: generateBookingCode(),
      user: userId,
      show: show._id,
      movie: show.movie._id,
      theatre: show.theatre._id,
      screen: show.screen._id,
      seats: uniqueSeats,
      showType: show.showType,
      numSeats: uniqueSeats.length,
      pricePerSeatBreakdown: costCalc.pricePerSeatBreakdown,
      subtotal: costCalc.subtotal,
      taxes: costCalc.taxes,
      totalAmount: costCalc.totalAmount,
      status: 'pending',
      routeQueue,
      priority,
      slaDeadline: new Date(now.getTime() + paymentSlaMinutes * 60000),
      escalationDeadline: new Date(now.getTime() + escalationSlaMinutes * 60000),
    });

    return booking;
  } catch (err) {
    // Roll back the seat reservation if booking creation fails for any reason
    await releaseSeats(showId, uniqueSeats);
    throw err;
  }
};

/** Cancels a booking and releases its seats back to the pool */
const cancelBooking = async (booking, reason) => {
  if (booking.status === 'cancelled') {
    throw new ValidationError('Booking is already cancelled');
  }
  if (booking.status === 'confirmed') {
    const showTime = await Show.findById(booking.show).select('startTime');
    if (showTime && new Date(showTime.startTime) <= new Date()) {
      throw new ValidationError('Cannot cancel a booking after the show has started');
    }
  }

  await releaseSeats(booking.show, booking.seats);

  booking.status = 'cancelled';
  booking.cancelledAt = new Date();
  booking.cancellationReason = reason || 'Cancelled by user';
  await booking.save();

  return booking;
};

module.exports = {
  createBooking,
  cancelBooking,
  reserveSeatsAtomically,
  releaseSeats,
  BookingConflictError,
  ValidationError,
};

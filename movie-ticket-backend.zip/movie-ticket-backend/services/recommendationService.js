/**
 * AI-based Movie Recommendation Service
 * A lightweight content-based recommendation engine (no external AI API needed):
 *  - Builds a genre-affinity profile from the user's past bookings + stated preferences
 *  - Scores now_showing/upcoming movies against that profile
 *  - Blends in a popularity score so new users still get sensible results (cold-start handling)
 */

const Booking = require('../models/Booking');
const Movie = require('../models/Movie');
const Show = require('../models/Show');

const buildGenreProfile = async (userId, user) => {
  const profile = {};

  // Weight from explicit stated preferences
  (user.preferences?.favoriteGenres || []).forEach((g) => {
    profile[g] = (profile[g] || 0) + 3;
  });

  // Weight from booking history (implicit signal - what they actually watched)
  const pastBookings = await Booking.find({ user: userId, status: { $in: ['confirmed'] } })
    .populate('movie', 'genre')
    .limit(50);

  pastBookings.forEach((b) => {
    (b.movie?.genre || []).forEach((g) => {
      profile[g] = (profile[g] || 0) + 1;
    });
  });

  return profile;
};

const scoreMovie = (movie, genreProfile) => {
  let score = 0;
  (movie.genre || []).forEach((g) => {
    if (genreProfile[g]) score += genreProfile[g];
  });
  // blend in popularity (normalized 0-10 scale) as a cold-start fallback signal
  score += (movie.popularityScore || 0) * 0.5;
  return score;
};

const getRecommendationsForUser = async (userId, user, limit = 10) => {
  const genreProfile = await buildGenreProfile(userId, user);
  const hasProfile = Object.keys(genreProfile).length > 0;

  const candidateMovies = await Movie.find({ status: { $in: ['now_showing', 'upcoming'] } }).lean();

  const scored = candidateMovies.map((movie) => ({
    movie,
    score: hasProfile ? scoreMovie(movie, genreProfile) : movie.popularityScore || 0,
  }));

  scored.sort((a, b) => b.score - a.score);

  return {
    strategy: hasProfile ? 'personalized_content_based' : 'popularity_fallback_cold_start',
    genreProfile,
    recommendations: scored.slice(0, limit).map((s) => ({
      movie: s.movie,
      matchScore: Math.round(s.score * 10) / 10,
    })),
  };
};

// Trending / most-booked movies right now — used for anonymous / guest users
const getTrendingMovies = async (limit = 10) => {
  const trending = await Show.aggregate([
    { $match: { status: { $in: ['scheduled', 'ongoing'] } } },
    { $group: { _id: '$movie', totalBooked: { $sum: { $size: '$bookedSeats' } }, showCount: { $sum: 1 } } },
    { $sort: { totalBooked: -1 } },
    { $limit: limit },
    { $lookup: { from: 'movies', localField: '_id', foreignField: '_id', as: 'movie' } },
    { $unwind: '$movie' },
    { $project: { movie: 1, totalBooked: 1, showCount: 1 } },
  ]);
  return trending;
};

module.exports = { getRecommendationsForUser, getTrendingMovies, buildGenreProfile };

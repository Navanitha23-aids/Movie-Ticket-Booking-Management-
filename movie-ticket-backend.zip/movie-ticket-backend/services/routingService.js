/**
 * Routing Service (feature 10: route booking based on show type)
 * Determines a processing queue/priority for a booking based on show type.
 * This is exposed in the booking response so an external orchestrator like
 * Pega can branch its case-management flow on `routeQueue` / `priority`.
 */
const { SHOW_TYPE_ROUTE_QUEUE } = require('../config/constants');

const PRIORITY_MAP = {
  Regular: 'normal',
  '3D': 'normal',
  IMAX: 'high',
  VIP: 'urgent',
};

const routeBookingByShowType = (showType) => {
  return {
    routeQueue: SHOW_TYPE_ROUTE_QUEUE[showType] || 'QUEUE_REGULAR_BOOKING',
    priority: PRIORITY_MAP[showType] || 'normal',
  };
};

module.exports = { routeBookingByShowType };

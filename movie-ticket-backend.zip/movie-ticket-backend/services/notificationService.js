/**
 * Notification Service (mock channel - logs + stores in DB as in_app notification)
 * In production this would call an email/SMS provider (SES, Twilio, etc.)
 * For this project all notifications are persisted to Mongo and can be polled
 * via GET /api/notifications - this is what Pega or a frontend would consume.
 */
const Notification = require('../models/Notification');
const logger = require('../utils/logger');

const sendNotification = async ({ userId, bookingId = null, type, title, message, channel = 'in_app' }) => {
  const notification = await Notification.create({
    user: userId,
    booking: bookingId,
    type,
    channel,
    title,
    message,
    status: 'sent', // mock mode: always "delivered" immediately
    sentAt: new Date(),
  });

  logger.info('Notification sent (mock)', { userId, type, channel, title });
  return notification;
};

const notifyBookingConfirmation = (booking, user) =>
  sendNotification({
    userId: user._id,
    bookingId: booking._id,
    type: 'booking_confirmation',
    title: 'Booking Confirmed!',
    message: `Your booking ${booking.bookingCode} for ${booking.numSeats} seat(s) is confirmed. Show time: ${new Date(
      booking.show?.startTime || Date.now()
    ).toLocaleString()}.`,
    channel: 'email',
  });

const notifyBookingCancellation = (booking, user, reason) =>
  sendNotification({
    userId: user._id,
    bookingId: booking._id,
    type: 'booking_cancellation',
    title: 'Booking Cancelled',
    message: `Your booking ${booking.bookingCode} has been cancelled. Reason: ${reason || 'Cancelled by user'}. Seats have been released.`,
    channel: 'email',
  });

const notifyShowReminder = (booking, user, hoursBefore) =>
  sendNotification({
    userId: user._id,
    bookingId: booking._id,
    type: 'show_reminder',
    title: 'Show Reminder',
    message: `Reminder: your movie starts in about ${hoursBefore} hour(s). Booking code: ${booking.bookingCode}. Seats: ${booking.seats.join(', ')}.`,
    channel: 'sms',
  });

const notifySLAEscalation = (booking, user) =>
  sendNotification({
    userId: user._id,
    bookingId: booking._id,
    type: 'sla_escalation',
    title: 'Booking Escalated',
    message: `Booking ${booking.bookingCode} breached its SLA and has been escalated to staff for manual review.`,
    channel: 'in_app',
  });

const notifyPaymentConfirmation = (booking, user, payment) =>
  sendNotification({
    userId: user._id,
    bookingId: booking._id,
    type: 'payment_confirmation',
    title: 'Payment Successful',
    message: `Payment of ${payment.amount} received for booking ${booking.bookingCode}. Transaction ID: ${payment.transactionId}.`,
    channel: 'email',
  });

module.exports = {
  sendNotification,
  notifyBookingConfirmation,
  notifyBookingCancellation,
  notifyShowReminder,
  notifySLAEscalation,
  notifyPaymentConfirmation,
};

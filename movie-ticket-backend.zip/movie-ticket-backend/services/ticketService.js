/**
 * QR-code e-ticket generation & verification service
 */
const QRCode = require('qrcode');
const crypto = require('crypto');

// Creates a signed payload so the QR can be verified offline without a DB round trip
// (still cross-checked against DB at verification time for status like cancellation)
const buildTicketPayload = (booking) => {
  const payload = {
    bookingCode: booking.bookingCode,
    bookingId: booking._id.toString(),
    showId: booking.show.toString(),
    seats: booking.seats,
    numSeats: booking.numSeats,
  };
  const signature = signPayload(payload);
  return { ...payload, signature };
};

const signPayload = (payload) => {
  const secret = process.env.JWT_SECRET || 'fallback_secret';
  const data = JSON.stringify(payload);
  return crypto.createHmac('sha256', secret).update(data).digest('hex');
};

const verifySignature = (payload, signature) => {
  const { signature: _omit, ...rest } = payload;
  const expected = signPayload(rest);
  return expected === signature;
};

/**
 * Generates a QR code (base64 data URL) encoding the ticket payload as JSON.
 */
const generateQRCode = async (booking) => {
  const payload = buildTicketPayload(booking);
  const qrDataUrl = await QRCode.toDataURL(JSON.stringify(payload), {
    errorCorrectionLevel: 'H',
    margin: 1,
    width: 320,
  });
  return qrDataUrl;
};

/**
 * Verifies a scanned QR payload string against signature + booking status.
 * @param {String} scannedDataString - raw JSON string decoded from the QR image
 * @param {Object} booking - the Booking document fetched by bookingCode
 */
const verifyTicket = (scannedDataString, booking) => {
  let payload;
  try {
    payload = JSON.parse(scannedDataString);
  } catch (e) {
    return { valid: false, reason: 'Malformed QR payload' };
  }

  if (!payload.signature || !verifySignature(payload, payload.signature)) {
    return { valid: false, reason: 'Invalid or tampered QR signature' };
  }

  if (!booking) {
    return { valid: false, reason: 'Booking not found' };
  }

  if (payload.bookingCode !== booking.bookingCode) {
    return { valid: false, reason: 'Booking code mismatch' };
  }

  if (booking.status === 'cancelled') {
    return { valid: false, reason: 'Booking has been cancelled' };
  }

  if (booking.status === 'expired') {
    return { valid: false, reason: 'Booking expired (SLA breach, never confirmed)' };
  }

  if (booking.status !== 'confirmed') {
    return { valid: false, reason: `Booking is not confirmed (status: ${booking.status})` };
  }

  if (booking.ticketVerified) {
    return { valid: false, reason: 'Ticket already used/verified', alreadyVerified: true };
  }

  return { valid: true, reason: 'Ticket verified successfully' };
};

module.exports = { generateQRCode, verifyTicket, buildTicketPayload };

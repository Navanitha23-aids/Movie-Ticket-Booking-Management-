/**
 * Mock Payment Service - simulates a payment gateway.
 * No real payment provider integration - deterministic mock behavior suitable
 * for demoing the full booking lifecycle end-to-end (and safe for Pega demos).
 */
const Payment = require('../models/Payment');
const { generateTransactionId } = require('../utils/generateCode');

/**
 * Simulates processing a payment. Fails only if amount <= 0 or method invalid,
 * otherwise always succeeds (deterministic for demo/testing purposes).
 */
const processMockPayment = async ({ bookingId, userId, amount, method = 'mock' }) => {
  const transactionId = generateTransactionId();

  if (!amount || amount <= 0) {
    const payment = await Payment.create({
      booking: bookingId,
      user: userId,
      amount: amount || 0,
      method,
      status: 'failed',
      transactionId,
      failureReason: 'Invalid payment amount',
    });
    return { success: false, payment };
  }

  const payment = await Payment.create({
    booking: bookingId,
    user: userId,
    amount,
    method,
    status: 'success',
    transactionId,
  });

  return { success: true, payment };
};

const refundMockPayment = async (paymentId) => {
  const payment = await Payment.findById(paymentId);
  if (!payment) return null;
  payment.status = 'refunded';
  payment.refundedAt = new Date();
  await payment.save();
  return payment;
};

module.exports = { processMockPayment, refundMockPayment };

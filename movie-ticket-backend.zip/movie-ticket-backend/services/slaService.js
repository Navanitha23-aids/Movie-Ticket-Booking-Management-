/**
 * Booking SLA & Escalation Service (feature 9)
 * Runs periodically (via node-cron in server.js) to:
 *   1. Auto-expire bookings that missed their payment SLA -> release seats
 *   2. Escalate bookings that are still pending past the escalation deadline
 *      (notifies staff/admin via notification + flags booking.isEscalated)
 */
const Booking = require('../models/Booking');
const User = require('../models/User');
const bookingService = require('./bookingService');
const notificationService = require('./notificationService');
const logger = require('../utils/logger');
const { ROLES } = require('../config/constants');

/** Expire bookings whose payment SLA has passed and they're still pending */
const expireOverdueBookings = async () => {
  const now = new Date();
  const overdue = await Booking.find({ status: 'pending', slaDeadline: { $lt: now } });

  for (const booking of overdue) {
    try {
      await bookingService.releaseSeats(booking.show, booking.seats);
      booking.status = 'expired';
      booking.slaBreachedStage = 'payment';
      await booking.save();
      logger.warn('Booking expired due to SLA breach (payment not completed)', {
        bookingId: booking._id.toString(),
        bookingCode: booking.bookingCode,
      });
    } catch (err) {
      logger.error('Failed to expire overdue booking', { bookingId: booking._id.toString(), error: err.message });
    }
  }

  return overdue.length;
};

/** Escalate bookings still pending past the escalation deadline (before hard expiry) */
const escalateBreachedBookings = async () => {
  const now = new Date();
  const toEscalate = await Booking.find({
    status: 'pending',
    isEscalated: false,
    escalationDeadline: { $lt: now },
    slaDeadline: { $gte: now }, // not yet hard-expired
  }).populate('user');

  const staffAndAdmins = await User.find({ role: { $in: [ROLES.STAFF, ROLES.MANAGER, ROLES.ADMIN] } });

  for (const booking of toEscalate) {
    try {
      booking.isEscalated = true;
      booking.escalatedAt = now;
      booking.slaBreachedStage = 'confirmation';
      await booking.save();

      // notify the customer
      if (booking.user) {
        await notificationService.notifySLAEscalation(booking, booking.user);
      }
      // notify all staff/admin/manager users so someone can follow up
      for (const staffUser of staffAndAdmins) {
        await notificationService.notifySLAEscalation(booking, staffUser);
      }

      logger.warn('Booking escalated due to SLA breach', {
        bookingId: booking._id.toString(),
        bookingCode: booking.bookingCode,
      });
    } catch (err) {
      logger.error('Failed to escalate booking', { bookingId: booking._id.toString(), error: err.message });
    }
  }

  return toEscalate.length;
};

/** Master tick function called by the cron job */
const runSLASweep = async () => {
  const escalatedCount = await escalateBreachedBookings();
  const expiredCount = await expireOverdueBookings();
  if (escalatedCount || expiredCount) {
    logger.info('SLA sweep completed', { escalatedCount, expiredCount });
  }
  return { escalatedCount, expiredCount };
};

module.exports = { runSLASweep, expireOverdueBookings, escalateBreachedBookings };

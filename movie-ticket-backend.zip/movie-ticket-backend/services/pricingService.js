/**
 * Dynamic Pricing Service
 * Computes seat price based on:
 *  - base show price
 *  - seat type multiplier (Regular/Premium/VIP/Recliner)
 *  - weekend / peak-time surcharge
 *  - demand-based surcharge (how full the show already is)
 */

const PEAK_HOURS = [18, 19, 20, 21, 22]; // 6 PM - 10:59 PM considered peak

const isWeekend = (date) => {
  const day = new Date(date).getDay();
  return day === 0 || day === 6; // Sunday=0, Saturday=6
};

const isPeakTime = (date) => {
  const hour = new Date(date).getHours();
  return PEAK_HOURS.includes(hour);
};

/**
 * Demand multiplier grows as the show fills up.
 * <40% booked  -> 1.0x
 * 40-70% booked -> 1.1x
 * 70-90% booked -> 1.25x
 * >90% booked   -> 1.4x
 */
const getDemandMultiplier = (bookedCount, totalSeats) => {
  if (!totalSeats) return 1;
  const occupancy = bookedCount / totalSeats;
  if (occupancy >= 0.9) return 1.4;
  if (occupancy >= 0.7) return 1.25;
  if (occupancy >= 0.4) return 1.1;
  return 1;
};

/**
 * Calculates the final price for a single seat.
 * @param {Object} params
 * @param {Number} params.basePrice - show base price
 * @param {Number} params.seatTypeMultiplier - from Seat.basePriceMultiplier
 * @param {Date} params.showDateTime - show start time
 * @param {Number} params.bookedCount - seats already booked for this show
 * @param {Number} params.totalSeats - total seats in the show
 */
const calculateSeatPrice = ({ basePrice, seatTypeMultiplier = 1, showDateTime, bookedCount = 0, totalSeats = 1 }) => {
  let price = basePrice * seatTypeMultiplier;

  const weekendSurchargeRate = isWeekend(showDateTime) ? 0.15 : 0;
  const peakSurchargeRate = isPeakTime(showDateTime) ? 0.1 : 0;
  const demandMultiplier = getDemandMultiplier(bookedCount, totalSeats);

  const surchargeMultiplier = 1 + weekendSurchargeRate + peakSurchargeRate;
  price = price * surchargeMultiplier * demandMultiplier;

  return {
    basePrice: round2(basePrice * seatTypeMultiplier),
    weekendSurchargeRate,
    peakSurchargeRate,
    demandMultiplier,
    finalPrice: round2(price),
  };
};

const round2 = (num) => Math.round(num * 100) / 100;

/**
 * Calculates full booking cost for a set of seats.
 * seatsInfo: [{ seatNumber, seatType, basePriceMultiplier }]
 */
const calculateBookingCost = ({ show, seatsInfo }) => {
  const bookedCount = show.bookedSeats.length;
  const totalSeats = show.totalSeats;

  const breakdown = seatsInfo.map((seat) => {
    const priceCalc = calculateSeatPrice({
      basePrice: show.basePrice,
      seatTypeMultiplier: seat.basePriceMultiplier || 1,
      showDateTime: show.startTime,
      bookedCount,
      totalSeats,
    });
    return {
      seatNumber: seat.seatNumber,
      seatType: seat.seatType,
      price: priceCalc.finalPrice,
    };
  });

  const subtotal = round2(breakdown.reduce((sum, s) => sum + s.price, 0));
  const taxRate = 0.09; // 9% GST-like mock tax (CGST+SGST style, kept simple)
  const taxes = round2(subtotal * taxRate);
  const totalAmount = round2(subtotal + taxes);

  return {
    pricePerSeatBreakdown: breakdown,
    subtotal,
    taxes,
    totalAmount,
  };
};

module.exports = {
  calculateSeatPrice,
  calculateBookingCost,
  isWeekend,
  isPeakTime,
  getDemandMultiplier,
};

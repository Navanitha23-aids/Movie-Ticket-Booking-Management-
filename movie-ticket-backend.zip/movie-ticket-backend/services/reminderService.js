/**
 * Automatic Show Reminder Service
 * Runs periodically to find confirmed bookings whose show starts within the
 * configured reminder window and haven't been reminded yet, then sends a
 * reminder notification.
 */
const Booking = require('../models/Booking');
const Show = require('../models/Show');
const notificationService = require('./notificationService');
const logger = require('../utils/logger');

// simple in-memory guard to avoid duplicate reminders within the same process run
// (paired with a DB flag for durability across restarts)
const sendShowReminders = async () => {
  const hoursBefore = parseFloat(process.env.SHOW_REMINDER_HOURS_BEFORE || '2');
  const now = new Date();
  const windowStart = now;
  const windowEnd = new Date(now.getTime() + hoursBefore * 60 * 60 * 1000);

  const upcomingShows = await Show.find({
    startTime: { $gte: windowStart, $lte: windowEnd },
    status: 'scheduled',
  }).select('_id');

  const showIds = upcomingShows.map((s) => s._id);
  if (showIds.length === 0) return 0;

  const bookingsToRemind = await Booking.find({
    show: { $in: showIds },
    status: 'confirmed',
    reminderSent: { $ne: true },
  }).populate('user');

  let count = 0;
  for (const booking of bookingsToRemind) {
    try {
      if (!booking.user) continue;
      await notificationService.notifyShowReminder(booking, booking.user, hoursBefore);
      booking.reminderSent = true;
      await booking.save();
      count++;
    } catch (err) {
      logger.error('Failed to send show reminder', { bookingId: booking._id.toString(), error: err.message });
    }
  }

  if (count > 0) logger.info('Show reminders sent', { count });
  return count;
};

module.exports = { sendShowReminders };

const { v4: uuidv4 } = require('uuid');

const generateBookingCode = () => {
  const raw = uuidv4().replace(/-/g, '').slice(0, 8).toUpperCase();
  return `BKG-${raw}`;
};

const generateTransactionId = () => {
  const raw = uuidv4().replace(/-/g, '').slice(0, 12).toUpperCase();
  return `TXN-${raw}`;
};

module.exports = { generateBookingCode, generateTransactionId };

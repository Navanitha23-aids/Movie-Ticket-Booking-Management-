require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const cron = require('node-cron');

const connectDB = require('./config/db');
const { notFound, errorHandler } = require('./middleware/errorMiddleware');
const logger = require('./utils/logger');

const slaService = require('./services/slaService');
const reminderService = require('./services/reminderService');

const app = express();

// ---------- Core middleware ----------
app.use(helmet());
app.use(
  cors({
    origin: process.env.CORS_ORIGIN === '*' ? '*' : (process.env.CORS_ORIGIN || '*').split(','),
  })
);
app.use(compression());
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

const limiter = rateLimit({
  windowMs: (parseInt(process.env.RATE_LIMIT_WINDOW_MINUTES || '15', 10)) * 60 * 1000,
  max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS || '200', 10),
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: 'Too many requests, please try again later.' },
});
app.use('/api/', limiter);

// ---------- Health check (useful for Pega connector health probes) ----------
app.get('/api/health', (req, res) => {
  res.status(200).json({ success: true, message: 'Movie Ticket Booking API is up', timestamp: new Date().toISOString() });
});

// ---------- Routes ----------
app.use('/api/auth', require('./routes/authRoutes'));
app.use('/api/movies', require('./routes/movieRoutes'));
app.use('/api/theatres', require('./routes/theatreRoutes'));
app.use('/api/screens', require('./routes/screenRoutes'));
app.use('/api/seats', require('./routes/seatRoutes'));
app.use('/api/shows', require('./routes/showRoutes'));
app.use('/api/bookings', require('./routes/bookingRoutes'));
app.use('/api/payments', require('./routes/paymentRoutes'));
app.use('/api/notifications', require('./routes/notificationRoutes'));
app.use('/api/recommendations', require('./routes/recommendationRoutes'));
app.use('/api/tickets', require('./routes/ticketRoutes'));
app.use('/api/analytics', require('./routes/analyticsRoutes'));

app.get('/', (req, res) => {
  res.json({
    success: true,
    message: 'Movie Ticket Booking Management API',
    docs: 'See README.md for full API documentation',
  });
});

// ---------- Error handling (must be last) ----------
app.use(notFound);
app.use(errorHandler);

const PORT = process.env.PORT || 5000;

const startServer = async () => {
  await connectDB();

  app.listen(PORT, () => {
    logger.info(`Server running in ${process.env.NODE_ENV || 'development'} mode on port ${PORT}`);
  });

  // ---------- Cron jobs ----------
  // SLA sweep: escalate/expire overdue pending bookings - runs every minute
  cron.schedule('* * * * *', async () => {
    try {
      await slaService.runSLASweep();
    } catch (err) {
      logger.error('SLA sweep cron failed', { error: err.message });
    }
  });

  // Show reminders: runs every 10 minutes
  cron.schedule('*/10 * * * *', async () => {
    try {
      await reminderService.sendShowReminders();
    } catch (err) {
      logger.error('Show reminder cron failed', { error: err.message });
    }
  });

  logger.info('Cron jobs scheduled: SLA sweep (every 1 min), show reminders (every 10 min)');
};

startServer();

// Graceful shutdown
process.on('unhandledRejection', (err) => {
  logger.error('Unhandled Rejection', { error: err.message });
});

module.exports = app;

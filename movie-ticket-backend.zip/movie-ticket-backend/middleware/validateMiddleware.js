const { validationResult } = require('express-validator');
const { failure } = require('../utils/apiResponse');

// Run after express-validator chains to short-circuit on invalid input
const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return failure(res, 422, 'Validation failed', errors.array().map((e) => ({ field: e.path, message: e.msg })));
  }
  next();
};

module.exports = { validate };

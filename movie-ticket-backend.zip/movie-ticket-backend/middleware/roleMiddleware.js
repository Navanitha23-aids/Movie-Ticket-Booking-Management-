const { failure } = require('../utils/apiResponse');

// Usage: authorize('admin', 'manager')
const authorize = (...allowedRoles) => {
  return (req, res, next) => {
    if (!req.user) {
      return failure(res, 401, 'Not authorized');
    }
    if (!allowedRoles.includes(req.user.role)) {
      return failure(res, 403, `Role '${req.user.role}' is not permitted to perform this action`);
    }
    next();
  };
};

module.exports = { authorize };

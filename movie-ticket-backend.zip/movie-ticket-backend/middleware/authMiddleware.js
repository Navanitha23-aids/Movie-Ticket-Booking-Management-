const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { failure } = require('../utils/apiResponse');

// Protects routes - verifies JWT and attaches req.user
const protect = async (req, res, next) => {
  try {
    let token;
    const authHeader = req.headers.authorization;

    if (authHeader && authHeader.startsWith('Bearer ')) {
      token = authHeader.split(' ')[1];
    }

    if (!token) {
      return failure(res, 401, 'Not authorized, no token provided');
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id);

    if (!user || !user.isActive) {
      return failure(res, 401, 'Not authorized, user not found or inactive');
    }

    req.user = user;
    next();
  } catch (error) {
    return failure(res, 401, 'Not authorized, token invalid or expired');
  }
};

module.exports = { protect };

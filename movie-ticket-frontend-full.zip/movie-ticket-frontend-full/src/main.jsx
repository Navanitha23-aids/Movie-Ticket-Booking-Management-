import React,{useState,useEffect} from 'react'
import {createRoot} from 'react-dom/client'
import {BrowserRouter,useNavigate,useLocation} from 'react-router-dom'
import './styles.css'
import {api} from './services/api'

const demoMovies=[
{id:1,title:'Coolie',genre:'Action • Drama',rating:8.4,duration:'2h 49m',language:'Tamil',poster:'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=700&q=80'},
{id:2,title:'Retro',genre:'Action • Romance',rating:8.1,duration:'2h 37m',language:'Tamil',poster:'https://images.unsplash.com/photo-1485846234645-a62644f84728?auto=format&fit=crop&w=700&q=80'},
{id:3,title:'Dragon',genre:'Comedy • Drama',rating:8.0,duration:'2h 35m',language:'Tamil',poster:'https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?auto=format&fit=crop&w=700&q=80'},
{id:4,title:'Leo',genre:'Action • Thriller',rating:8.7,duration:'2h 44m',language:'Tamil',poster:'https://images.unsplash.com/photo-1440404653325-ab127d49abc1?auto=format&fit=crop&w=700&q=80'}
]
const shows=[{id:1,theatre:'PVR Cinemas',area:'Coimbatore',time:'10:30 AM',price:180},{id:2,theatre:'INOX',area:'Coimbatore',time:'1:30 PM',price:180},{id:3,theatre:'KG Cinemas',area:'Coimbatore',time:'7:30 PM',price:220}]
const booked=[3,8,17,24,31,38]

function App(){
 const [user,setUser]=useState(()=>JSON.parse(localStorage.getItem('cine_user')||'null'))
 const [selectedMovie,setSelectedMovie]=useState(null)
 const [selectedShow,setSelectedShow]=useState(shows[2])
 const [seats,setSeats]=useState([])
 const [bookings,setBookings]=useState(()=>JSON.parse(localStorage.getItem('cine_bookings')||'[]'))
 const [chat,setChat]=useState(false)
 const [admin,setAdmin]=useState(false)
 useEffect(()=>localStorage.setItem('cine_bookings',JSON.stringify(bookings)),[bookings])
 const nav=useNavigate(); const loc=useLocation()

 const logout=()=>{setUser(null);localStorage.removeItem('cine_user');nav('/')}
 const openMovie=m=>{setSelectedMovie(m);nav('/movie')}
 const doBooking=()=>{if(!user){nav('/login');return} if(!seats.length)return; const b={id:'CB'+Date.now(),movie:selectedMovie.title,show:selectedShow,seats:[...seats],total:seats.length*selectedShow.price,date:new Date().toLocaleDateString()};setBookings([b,...bookings]);setSeats([]);nav('/ticket',{state:{booking:b}})}
 return <div className="app">
   <Header user={user} onLogout={logout} onAdmin={()=>setAdmin(!admin)}/>
   <RoutesView {...{loc,nav,user,setUser,selectedMovie,setSelectedMovie,openMovie,selectedShow,setSelectedShow,seats,setSeats,bookings,doBooking,admin}}/>
   <button className="chat-fab" onClick={()=>setChat(true)}>🤖</button>
   {chat&&<Chatbot close={()=>setChat(false)} user={user}/>}
 </div>
}

function Header({user,onLogout,onAdmin}){
 const nav=useNavigate()
 return <header><div className="brand" onClick={()=>nav('/')}>🎬 <b>CineBook</b></div><nav><button onClick={()=>nav('/')}>Home</button><button onClick={()=>nav('/movies')}>Movies</button><button onClick={()=>nav('/bookings')}>My Tickets</button>{user?.role==='admin'&&<button onClick={onAdmin}>Admin</button>}{user?<><span className="welcome">Hi, {user.name}</span><button onClick={onLogout}>Logout</button></>:<button onClick={()=>nav('/login')}>Login</button>}</nav></header>
}

function RoutesView(p){
 const path=p.loc.pathname
 if(p.admin && p.user?.role==='admin') return <AdminPage/>
 if(path==='/login')return <Login setUser={p.setUser}/>
 if(path==='/movies')return <Movies movies={demoMovies} open={p.openMovie}/>
 if(path==='/movie')return <MovieDetails movie={p.selectedMovie||demoMovies[0]} nav={p.nav} setMovie={p.setSelectedMovie}/>
 if(path==='/shows')return <Shows movie={p.selectedMovie||demoMovies[0]} show={p.selectedShow} setShow={p.setSelectedShow} nav={p.nav}/>
 if(path==='/seats')return <Seats movie={p.selectedMovie||demoMovies[0]} show={p.selectedShow} seats={p.seats} setSeats={p.setSeats} booked={booked} confirm={p.doBooking}/>
 if(path==='/ticket')return <Ticket booking={p.loc.state?.booking||p.bookings[0]} nav={p.nav}/>
 if(path==='/bookings')return <Bookings bookings={p.bookings} nav={p.nav}/>
 return <Home open={p.openMovie}/>
}

function Home({open}){return <><section className="hero"><div><small>SMART MOVIE TICKETING</small><h1>Book your<br/><em>movie experience.</em></h1><p>Find movies, theatres and showtimes. Pick your seats and get your digital ticket instantly.</p><button className="primary" onClick={()=>location.href='/movies'}>Explore Movies →</button></div></section><section className="section"><div className="section-title"><h2>Now Showing</h2><a href="/movies">View all</a></div><div className="grid">{demoMovies.map(m=><MovieCard key={m.id} m={m} open={open}/>)}</div></section><section className="features"><Feature icon="🤖" title="AI Movie Assistant" text="Ask for movie recommendations, showtimes and booking help."/><Feature icon="💺" title="Smart Seat Selection" text="See available and booked seats in real time."/><Feature icon="🎟️" title="Digital Tickets" text="Keep your booking details and ticket reference in one place."/><Feature icon="🔔" title="Booking Alerts" text="Ready for backend notification and reminder integration." /></section></>}

function Feature({icon,title,text}){return <div className="feature"><span>{icon}</span><h3>{title}</h3><p>{text}</p></div>}
function MovieCard({m,open}){return <article className="movie-card"><img src={m.poster}/><div className="movie-info"><div className="rating">⭐ {m.rating}</div><h3>{m.title}</h3><p>{m.genre}</p><button onClick={()=>open(m)}>Book Tickets</button></div></article>}
function Movies({open}){const [q,setQ]=useState('');const list=demoMovies.filter(m=>m.title.toLowerCase().includes(q.toLowerCase())||m.genre.toLowerCase().includes(q.toLowerCase()));return <main className="page"><h1>Movies</h1><input className="search" placeholder="🔍 Search movies..." value={q} onChange={e=>setQ(e.target.value)}/><div className="grid">{list.map(m=><MovieCard key={m.id} m={m} open={open}/>)}</div></main>}
function MovieDetails({movie,nav,setMovie}){return <main className="page details"><img src={movie.poster}/><div><span className="pill">⭐ {movie.rating}</span><h1>{movie.title}</h1><p>{movie.genre} • {movie.duration} • {movie.language}</p><p className="muted">Enjoy a complete booking flow with theatre selection, showtimes, live seat selection, payment-ready booking and digital ticket generation.</p><h3>Available actions</h3><ul><li>Choose theatre and showtime</li><li>Select available seats</li><li>Confirm booking and receive ticket</li></ul><button className="primary" onClick={()=>{setMovie(movie);nav('/shows')}}>Choose Show →</button></div></main>}
function Shows({movie,show,setShow,nav}){return <main className="page"><h1>Choose Theatre & Show</h1><p className="muted">{movie.title}</p><div className="show-list">{shows.map(s=><button className={'show '+(show.id===s.id?'active':'')} key={s.id} onClick={()=>setShow(s)}><b>{s.theatre}</b><span>{s.area}</span><strong>{s.time}</strong><small>₹{s.price}/seat</small></button>)}</div><button className="primary" onClick={()=>nav('/seats')}>Select Seats →</button></main>}
function Seats({movie,show,seats,setSeats,booked,confirm}){const toggle=n=>{if(booked.includes(n))return;setSeats(s=>s.includes(n)?s.filter(x=>x!==n):[...s,n])};return <main className="page"><h1>Select Seats</h1><p className="muted">{movie.title} • {show.theatre} • {show.time}</p><div className="legend"><span>🟩 Available</span><span>🟨 Selected</span><span>🟥 Booked</span></div><div className="screen">SCREEN</div><div className="seat-map">{Array.from({length:40},(_,i)=>{let n=i+1;return <button key={n} disabled={booked.includes(n)} className={'seat '+(seats.includes(n)?'selected ':'')+(booked.includes(n)?'booked':'')} onClick={()=>toggle(n)}>{n}</button>})}</div><div className="booking-bar"><span>{seats.length} seats</span><b>₹{seats.length*show.price}</b><button className="primary" disabled={!seats.length} onClick={confirm}>Continue</button></div></main>}
function Login({setUser}){const [name,setName]=useState('');const nav=useNavigate();const submit=e=>{e.preventDefault();const u={name:name||'Guest',email:(name||'guest').toLowerCase().replace(/\\s/g,'')+'@demo.com',role:name.toLowerCase().includes('admin')?'admin':'user'};localStorage.setItem('cine_user',JSON.stringify(u));setUser(u);nav('/')};return <main className="auth"><form onSubmit={submit}><h1>Welcome Back</h1><p className="muted">Login to book and manage your tickets.</p><input required placeholder="Your name" value={name} onChange={e=>setName(e.target.value)}/><input placeholder="Email"/><input type="password" placeholder="Password"/><button className="primary">Login / Sign Up</button><small>Demo: enter a name containing “admin” to preview admin dashboard.</small></form></main>}
function Bookings({bookings,nav}){return <main className="page"><h1>My Tickets</h1>{!bookings.length?<div className="empty">No bookings yet. <button onClick={()=>nav('/movies')}>Browse movies</button></div>:<div className="booking-list">{bookings.map(b=><div className="booking" key={b.id}><div><span className="pill">CONFIRMED</span><h2>{b.movie}</h2><p>{b.show.theatre} • {b.show.time}</p><p>Seats: {b.seats.join(', ')}</p></div><div><b>₹{b.total}</b><p>{b.id}</p></div></div>)}</div>}</main>}
function Ticket({booking,nav}){if(!booking)return <main className="page"><div className="empty">No ticket selected.</div></main>;return <main className="ticket-page"><div className="ticket"><div className="success">✓</div><h1>Booking Confirmed</h1><p className="muted">Your digital movie ticket</p><hr/><h2>{booking.movie}</h2><p>{booking.show.theatre} • {booking.show.time}</p><p><b>Seats:</b> {booking.seats.join(', ')}</p><p><b>Date:</b> {booking.date}</p><p><b>Total:</b> ₹{booking.total}</p><div className="code">{booking.id}</div><button className="primary" onClick={()=>nav('/bookings')}>My Tickets</button></div></main>}
function Chatbot({close,user}){const [msgs,setMsgs]=useState([{from:'bot',text:'Hi! 👋 I am CineBook AI. Ask me about movies, recommendations, shows, seats or booking.'}]);const [text,setText]=useState('');const send=async()=>{if(!text.trim())return;const q=text;setText('');setMsgs(m=>[...m,{from:'user',text:q}]);try{const r=await api.chat(q,user);setMsgs(m=>[...m,{from:'bot',text:r.message||r.reply||'I can help with movies and bookings.'}])}catch{let a=q.toLowerCase().includes('recommend')?'Try Coolie or Leo based on current ratings.':q.toLowerCase().includes('seat')?'Open a movie and choose a show to see available seats.':q.toLowerCase().includes('book')?'Choose a movie → show → seats → confirm booking.':'I can help with movie recommendations, showtimes, seats and bookings.';setMsgs(m=>[...m,{from:'bot',text:a}])}};return <div className="chat-overlay"><div className="chat"><div className="chat-head"><b>🤖 CineBook AI</b><button onClick={close}>×</button></div><div className="messages">{msgs.map((m,i)=><div key={i} className={m.from}>{m.text}</div>)}</div><div className="chat-input"><input value={text} onChange={e=>setText(e.target.value)} onKeyDown={e=>e.key==='Enter'&&send()} placeholder="Ask anything..."/><button onClick={send}>➤</button></div></div></div>}
function AdminPage(){return <main className="page"><h1>Admin Dashboard</h1><p className="muted">Movie ticket management console.</p><div className="stats"><div><b>128</b><span>Total Users</span></div><div><b>64</b><span>Today's Bookings</span></div><div><b>₹18,420</b><span>Revenue</span></div><div><b>12</b><span>Movies</span></div></div><div className="admin-grid"><div><h2>Movie Management</h2><button>Add Movie</button><button>Edit Movie</button><button>Delete Movie</button></div><div><h2>Show Management</h2><button>Add Theatre</button><button>Add Show</button><button>Manage Seats</button></div><div><h2>Booking Management</h2><button>View Bookings</button><button>Refunds</button><button>Reports</button></div></div></main>}
function AppWrapper(){return <BrowserRouter><App/></BrowserRouter>}
createRoot(document.getElementById('root')).render(<AppWrapper/>)
const BASE_URL=import.meta.env.VITE_API_URL||'http://localhost:5000/api'
async function request(path,options={}){const res=await fetch(BASE_URL+path,{headers:{'Content-Type':'application/json',...(options.headers||{})},...options});if(!res.ok)throw new Error(await res.text());return res.json()}
export const api={
 login:(data)=>request('/auth/login',{method:'POST',body:JSON.stringify(data)}),
 register:(data)=>request('/auth/register',{method:'POST',body:JSON.stringify(data)}),
 movies:()=>request('/movies'),
 movie:(id)=>request('/movies/'+id),
 theatres:(movieId)=>request('/theatres?movieId='+movieId),
 shows:(theatreId,date)=>request('/shows?theatreId='+theatreId+'&date='+date),
 seats:(showId)=>request('/seats?showId='+showId),
 book:(data)=>request('/bookings',{method:'POST',body:JSON.stringify(data)}),
 bookings:()=>request('/bookings'),
 payment:(data)=>request('/payments',{method:'POST',body:JSON.stringify(data)}),
 chat:(message,user)=>request('/chat',{method:'POST',body:JSON.stringify({message,user})}),
 reviews:(movieId)=>request('/movies/'+movieId+'/reviews'),
 addReview:(movieId,data)=>request('/movies/'+movieId+'/reviews',{method:'POST',body:JSON.stringify(data)}),
 notifications:()=>request('/notifications'),
 adminDashboard:()=>request('/admin/dashboard')
}
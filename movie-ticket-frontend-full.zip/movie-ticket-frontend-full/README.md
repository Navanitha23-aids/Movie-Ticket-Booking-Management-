# CineBook Movie Ticket Frontend

## Run
npm.cmd install
npm.cmd run dev

## Backend connection
Create `.env` from `.env.example` and set:
VITE_API_URL=http://localhost:5000/api

The API service is in `src/services/api.js`. It is intentionally isolated so the endpoint paths can be changed easily if your backend uses different route names.

## Included UI
Home, movie search, movie details, theatre/show selection, seat map, login/signup demo, booking confirmation, booking history, AI chatbot UI, admin dashboard preview, reviews/notification/payment-ready API service.

## Important
The app includes demo data so the screens can be previewed before the backend is connected. Once the backend is running, replace/use the API routes in `src/services/api.js` to match the exact routes exposed by your backend.
